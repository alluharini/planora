# app.py
from flask import Flask, request, jsonify
import os
import json
import re
from google import genai  

app = Flask(__name__)

#MODEL = os.getenv("GEMINI_MODEL", "gemini-1.5-pro")
MODEL = "gemini-1.5-flash"

client = genai.Client(api_key=os.getenv("GEMINI_API_KEY"))

# --- Helper to call Gemini robustly ---
def call_gemini(prompt, model=MODEL, max_output_tokens=400):
    """
    Calls Gemini and returns the plain text response (best-effort).
    """
    resp = client.models.generate_content(model=model, contents=prompt)

    # Try a few common attribute names depending on SDK version
    text = getattr(resp, "text", None)
    if not text:
        # some SDKs use 'candidates' or 'generations'
        candidates = getattr(resp, "candidates", None)
        if candidates and len(candidates) > 0:
            # candidate may have `.content` or `.text`
            text = getattr(candidates[0], "content", None) or getattr(candidates[0], "text", None)

    if not text:
        gens = getattr(resp, "generations", None)
        if gens and len(gens) > 0:
            text = getattr(gens[0], "text", None) or getattr(gens[0], "content", None)

    return text or ""

def parse_json_safe(text):
    """
    Try to extract JSON from model text. If it fails, return None.
    """
    if not text or not text.strip():
        return None
    # try direct JSON
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        pass

    # try to find JSON substring {...} or [...]
    m = re.search(r'(\{[\s\S]*\}|\[[\s\S]*\])', text)
    if m:
        try:
            return json.loads(m.group(0))
        except json.JSONDecodeError:
            return None
    return None

def text_to_list_fallback(text):
    """
    If JSON parsing fails, convert sensible lines / bullets into a list of strings.
    """
    if not text:
        return []
    lines = []
    for line in text.splitlines():
        clean = line.strip().lstrip("-*• \t")
        if clean:
            # discard numeric labels like "1." prefix
            clean = re.sub(r'^\d+\.\s*', '', clean)
            lines.append(clean)
    # if the entire response was a single comma-separated line, split that
    if len(lines) == 1 and "," in lines[0]:
        parts = [p.strip() for p in lines[0].split(",") if p.strip()]
        if len(parts) > 1:
            return parts
    return lines

# --- Gemini-backed functions (replace CSV lookups) ---
def generate_dishes_for_ingredient(ingredient, max_results=10):
    prompt = f"""
You are an expert recipe assistant. Given the ingredient below, return a JSON object with a single key "dishes"
whose value is an array of dish names (strings) that commonly use this ingredient. Return plain JSON only (no explanation).
Ingredient: "{ingredient}"
Limit results to at most {max_results} dish names.
Example output:
{{ "dishes": ["Dish A", "Dish B"] }}
"""
    resp_text = call_gemini(prompt)
    parsed = parse_json_safe(resp_text)
    if parsed and isinstance(parsed, dict) and "dishes" in parsed:
        return parsed["dishes"]
    # fallback to text parsing
    return text_to_list_fallback(resp_text)

def generate_ingredients_for_dish(dish_name, max_results=50):
    prompt = f"""
You are an expert chef. Given the dish name below, return a JSON object with a single key "ingredients"
whose value is an array of the grocery ingredients (strings) required to make a simple home-cooked version of the dish.
Return plain JSON only (no explanation).
Dish: "{dish_name}"
Limit to {max_results} items.
Example output:
{{ "ingredients": ["1 lb chicken", "2 tbsp butter", "1 onion", ...] }}
"""
    resp_text = call_gemini(prompt)
    parsed = parse_json_safe(resp_text)
    if parsed and isinstance(parsed, dict) and "ingredients" in parsed:
        return parsed["ingredients"]
    # fallback to text parsing
    return text_to_list_fallback(resp_text)

# --- Routes (unchanged endpoints/signatures) ---

# Search by ingredient → return dishes
@app.route("/recommend_food", methods=["POST"])
def recommend_food():
    try:
        ingredient_input = request.form.get('ingredient')
        if not ingredient_input:
            return jsonify({"status": False, "message": "Missing ingredient parameter.", "data": []}), 400

        recommended_dishes = generate_dishes_for_ingredient(ingredient_input)

        if not recommended_dishes:
            return jsonify({
                "status": False,
                "message": f"No matching dishes found for the ingredient '{ingredient_input}'.",
                "data": []
            }), 404

        return jsonify({
            "status": True,
            "message": "Food recommendation successful.",
            "data": recommended_dishes
        })

    except Exception as e:
        return jsonify({"status": False, "message": f"Error: {str(e)}", "data": []}), 500


# Search by dish name (fuzzy) → return ingredients
@app.route("/dish_ingredients", methods=["POST"])
def dish_ingredients():
    try:
        dish_input = request.form.get('dish')
        if not dish_input:
            return jsonify({"status": False, "message": "Missing dish parameter.", "data": []}), 400

        ingredients = generate_ingredients_for_dish(dish_input)

        if not ingredients:
            return jsonify({
                "status": False,
                "message": f"No close match / ingredients found for '{dish_input}'.",
                "data": []
            }), 404

        return jsonify({
            "status": True,
            "message": "Dish ingredients found (AI-generated).",
            "data": ingredients
        })

    except Exception as e:
        return jsonify({"status": False, "message": f"Error: {str(e)}", "data": []}), 500


if __name__ == "__main__":
    # debug True for local testing only
    app.run(debug=True, host="0.0.0.0", port=int(os.getenv("PORT", 5000)))
