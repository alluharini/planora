import SwiftUI

// Response model for signup
struct SignupResponseModel: Codable {
    let status: Bool
    let message: String
    let data: [SignupData]
}

struct SignupData: Codable {
    let id: Int
    let name: String
    let email: String
}

struct signuppage: View {
    @State private var email = ""
    @State private var fullName = ""
    @State private var password = ""
    @State private var confirmPassword = ""

    @State private var isEmailValid = true
    @State private var isPasswordValid = true
    @State private var isConfirmPasswordValid = true
    @State private var isProcessing = false
    @State private var navigateToLogin = false
    @State private var showAlert = false
    @State private var alertMessage = ""

    // Animation state
    @State private var isAnimating = false

    private func registerUser() {
        guard validateFields() else { return }

        isProcessing = true
        let parameters: [String: String] = [
            "email": email,
            "name": fullName,
            "password": password
        ]

        APIHandler.shared.postAPIValues(
            type: SignupResponseModel.self,
            apiUrl: APIList.registerUrl,
            method: "POST",
            formData: parameters
        ) { result in
            DispatchQueue.main.async {
                isProcessing = false
                switch result {
                case .success(let response):
                    if response.status {
                        UserDefaults.standard.set(fullName, forKey: "username")
                        alertMessage = response.message
                        showAlert = true
                        navigateToLogin = true
                    } else {
                        alertMessage = response.message
                        showAlert = true
                    }
                case .failure(let error):
                    if error is DecodingError {
                        UserDefaults.standard.set(fullName, forKey: "username")
                        alertMessage = "Registration successful! Please log in."
                        showAlert = true
                        navigateToLogin = true
                    } else {
                        alertMessage = "Registration failed: \(error.localizedDescription)"
                        showAlert = true
                    }
                }
            }
        }
    }

    private func validateFields() -> Bool {
        isEmailValid = true
        isPasswordValid = true
        isConfirmPasswordValid = true

        if email.isEmpty {
            isEmailValid = false
            alertMessage = "Email is required"
            showAlert = true
            return false
        }

        if fullName.isEmpty {
            alertMessage = "Full name is required"
            showAlert = true
            return false
        }

        if password.isEmpty {
            isPasswordValid = false
            alertMessage = "Password is required"
            showAlert = true
            return false
        }

        if confirmPassword.isEmpty {
            isConfirmPasswordValid = false
            alertMessage = "Please confirm your password"
            showAlert = true
            return false
        }

        if !isValidEmail(email) {
            isEmailValid = false
            alertMessage = "Please enter a valid email address"
            showAlert = true
            return false
        }

        if password != confirmPassword {
            isConfirmPasswordValid = false
            alertMessage = "Passwords do not match"
            showAlert = true
            return false
        }

        return true
    }

    private func isValidEmail(_ email: String) -> Bool {
        let emailRegex = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}"
        let emailTest = NSPredicate(format: "SELF MATCHES %@", emailRegex)
        return emailTest.evaluate(with: email)
    }

    var body: some View {
        NavigationStack {
            ZStack {
                Image("background")
                    .resizable()
                    .aspectRatio(contentMode: .fill)
                    .ignoresSafeArea()
                    .blur(radius: 5)

                Color.black.opacity(0.4)
                    .ignoresSafeArea()

                VStack(spacing: 30) {
                    // Title
                    Text("Create Account")
                        .font(.system(size: 36, weight: .bold))
                        .foregroundColor(.blue) // same as login
                        .shadow(radius: 2)

                    // Subtitle
                    Text("Please fill out the information below")
                        .font(.system(size: 18, weight: .semibold))
                        .foregroundColor(.white)
                        .multilineTextAlignment(.center)

                    // Fields
                    VStack(spacing: 18) {
                        TextField("Email", text: $email)
                            .keyboardType(.emailAddress)
                            .autocapitalization(.none)
                            .modifier(CustomTextFieldStyle(isValid: isEmailValid))

                        TextField("First and Last Name", text: $fullName)
                            .modifier(CustomTextFieldStyle(isValid: true))

                        SecureField("Password", text: $password)
                            .modifier(CustomTextFieldStyle(isValid: isPasswordValid))

                        SecureField("Confirm Password", text: $confirmPassword)
                            .modifier(CustomTextFieldStyle(isValid: isConfirmPasswordValid))
                    }
                    .padding(.horizontal, 30)

                    // Button
                    Button(action: {
                        if validateFields() {
                            isProcessing = true
                            registerUser()
                        }
                    }) {
                        Text(isProcessing ? "Creating..." : "Create Account")
                            .font(.headline)
                            .foregroundColor(.white)
                            .frame(maxWidth: 340)
                            .frame(height: 50)
                            .background(
                                LinearGradient(gradient: Gradient(colors: [
                                    Color(red: 0.4, green: 0.2, blue: 0.8),
                                    Color(red: 0.3, green: 0.3, blue: 0.9)
                                ]), startPoint: .leading, endPoint: .trailing)
                            )
                            .cornerRadius(12)
                            .shadow(radius: 5)
                    }
                    .padding(.horizontal, 30)
                    .disabled(isProcessing)

                    // Link
                    NavigationLink(destination: loginpage()) {
                        HStack {
                            Text("Already a user?")
                            Text("Please log in")
                                .fontWeight(.bold)
                        }
                        .foregroundColor(.white)
                    }
                }
                .frame(maxHeight: .infinity) // center vertically
                .padding(.horizontal)
                .opacity(isAnimating ? 1 : 0)
                .offset(y: isAnimating ? 0 : 20)
            }
            .navigationBarHidden(true)
            .alert(isPresented: $showAlert) {
                Alert(
                    title: Text("Registration"),
                    message: Text(alertMessage),
                    dismissButton: .default(Text("OK")) {
                        if navigateToLogin {
                            navigateToLogin = false
                        }
                    }
                )
            }
            .onAppear {
                withAnimation(.easeOut(duration: 0.8)) {
                    isAnimating = true
                }
            }
        }
    }
}

struct CustomTextFieldStyle: ViewModifier {
    var isValid: Bool

    func body(content: Content) -> some View {
        content
            .padding()
            .background(Color.white.opacity(0.9))
            .cornerRadius(10)
            .overlay(
                RoundedRectangle(cornerRadius: 10)
                    .stroke(isValid ? Color.gray.opacity(0.4) : Color.red, lineWidth: 2)
            )
            .foregroundColor(.black)
            .font(.system(size: 16))
    }
}

struct signuppage_Previews: PreviewProvider {
    static var previews: some View {
        signuppage()
    }
}

