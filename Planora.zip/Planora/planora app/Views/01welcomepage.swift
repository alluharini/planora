import SwiftUI

struct welcomepage: View {
    @State private var showGetStarted = false

    var body: some View {
        GeometryReader { geometry in
            ZStack {
                VStack(spacing: geometry.size.height * 0.02) {
                    VStack(spacing: 0) {
                        Text("Welcome to")
                            .font(.system(size: geometry.size.width * 0.12))
                            .fontWeight(.bold)
                            .foregroundColor(.purple)
                            .padding(.top, 20)

                        Text("Planora")
                            .font(.system(size: geometry.size.width * 0.12))
                            .fontWeight(.bold)
                            .foregroundColor(.purple)
                            .padding(.top, 5)
                    }
                    .multilineTextAlignment(.center)
                    .padding(.horizontal)

                    Text("Where Every Detail Meets Perfection")
                        .font(.system(size: geometry.size.width * 0.05))
                        .fontWeight(.semibold)
                        .foregroundColor(Color.purple.opacity(0.7))
                        .multilineTextAlignment(.center)
                        .padding(.horizontal, 10)
                        .padding(.top, 2)

                    Image("party")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(height: geometry.size.height * 0.46)
                        .cornerRadius(30)
                        .padding(.top, geometry.size.height * 0.04)

                    Button(action: {
                        // Simply toggle state, no system modal
                        showGetStarted = true
                    }) {
                        Text("   Get Started")
                            .font(.system(size: geometry.size.width * 0.08, weight: .semibold))
                            .foregroundColor(.white)
                            .padding()
                            .frame(maxWidth: .infinity)
                            .background(
                                LinearGradient(
                                    gradient: Gradient(colors: [Color.purple, Color.blue]),
                                    startPoint: .leading,
                                    endPoint: .trailing
                                )
                            )
                            .cornerRadius(40)
                            .shadow(color: Color.purple.opacity(0.3), radius: 6, x: 0, y: 3)
                    }
                    .padding(.top, geometry.size.height * 0.055)
                    .padding(.horizontal, geometry.size.width * 0.04)

                    Spacer(minLength: 15)
                }
                .frame(width: geometry.size.width, height: geometry.size.height)

                // Overlay the getstarted view instantly
                if showGetStarted {
                    getstarted()
                        .transition(.identity) // No animation at all
                        .zIndex(1)
                }
            }
        }
        .navigationBarBackButtonHidden(true) 
    }
}


struct welcomepage_Previews: PreviewProvider {
    static var previews: some View {
        welcomepage()
            .previewDevice("iPhone 16 Pro")
    }
}

