import SwiftUI

struct GroceryListView: View {
    @State private var items: [GroceryItem] = []
    @State private var newItemName = ""
    @State private var showAlert = false
    @State private var alertMessage = ""

    var body: some View {
        GeometryReader { geometry in
            VStack {
                // Header
                Text("🛒 Grocery List")
                    .font(.system(size: min(geometry.size.width * 0.08, 36), weight: .bold, design: .serif))
                    .italic()
                    .foregroundColor(Color.purple)
                    .padding(.top, geometry.size.height * 0.01)

                // Add Item Section
                HStack {
                    TextField("Enter grocery item", text: $newItemName)
                        .padding()
                        .background(Color(.systemGray6))
                        .cornerRadius(10)
                        .font(.system(size: 18))
                        .padding(.leading)

                    Button(action: {
                        if newItemName.isEmpty {
                            alertMessage = "Please enter an item"
                            showAlert = true
                        } else {
                            addGroceryApiCall(name: newItemName)
                        }
                    }) {
                        Text("Add")
                            .foregroundColor(.white)
                            .padding(.horizontal, 20)
                            .padding(.vertical, 12)
                            .background(Color.purple)
                            .cornerRadius(10)
                    }
                    .padding(.trailing)
                }

                // Grocery Items List
                if items.isEmpty {
                    Spacer()
                    VStack {
                        Image(systemName: "cart.badge.plus")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 100, height: 100)
                            .foregroundColor(.gray)
                        Text("Your grocery list is empty.")
                            .foregroundColor(.gray)
                            .font(.headline)
                            .padding(.top, 8)
                    }
                    Spacer()
                } else {
                    List {
                        ForEach(items) { item in
                            HStack {
                                // Checkbox
                                Button(action: {
                                    if let idx = items.firstIndex(where: { $0.id == item.id }) {
                                        items[idx].is_checked = (items[idx].is_checked ?? 0) == 1 ? 0 : 1
                                    }
                                    toggleGroceryApiCall(id: item.id, isChecked: (item.is_checked ?? 0) == 1 ? 0 : 1)
                                }) {
                                    Image(systemName: item.isCheckedBool ? "checkmark.square.fill" : "square")
                                        .resizable()
                                        .frame(width: 24, height: 24)
                                        .foregroundColor(.purple)
                                }
                                .buttonStyle(BorderlessButtonStyle()) // important

                                // Item name
                                Text(item.name ?? "")
                                    .foregroundColor(.black)
                                    .font(.system(size: 18, design: .serif))
                                    .italic()
                                    .padding(.leading, 5)

                                Spacer()

                                // Trash button
                                Button(action: {
                                    if let idx = items.firstIndex(where: { $0.id == item.id }) {
                                        items.remove(at: idx)
                                    }
                                    deleteGroceryApiCall(id: item.id)
                                }) {
                                    Image(systemName: "trash")
                                        .foregroundColor(.red)
                                        .padding(6)
                                }
                                .buttonStyle(BorderlessButtonStyle()) // important
                            }
                        }
                        .onDelete(perform: deleteItem) // swipe-to-delete
                    }
                    .listStyle(PlainListStyle())
                }

                Spacer()
            }
            .background(Color(.systemGray5).ignoresSafeArea())
        }
        .onAppear {
            fetchGroceriesApiCall()
        }
        .alert("Message", isPresented: $showAlert) {
            Button("OK", role: .cancel) { }
        } message: {
            Text(alertMessage)
        }
    }

    // MARK: - API Calls

    func addGroceryApiCall(name: String) {
        let params: [String: Any] = [
            "email": Manager.shared.email,
            "name": name
        ]

        APIHandler.shared.postAPIValues(
            type: GroceryResponseModel.self,
            apiUrl: APIList.add_groceryURl,
            method: "POST",
            formData: params
        ) { result in
            DispatchQueue.main.async {
                switch result {
                case .success(let response):
                    // Add returned item to list if present
                    if let returned = response.data {
                        items.insert(contentsOf: returned, at: 0)
                    } else {
                        fetchGroceriesApiCall()
                    }
                    newItemName = ""
                case .failure(let err):
                    alertMessage = "Failed to add item: \(err.localizedDescription)"
                    showAlert = true
                }
            }
        }
    }

    func fetchGroceriesApiCall() {
        let urlWithEmail = "\(APIList.get_groceryURl)?email=\(Manager.shared.email)"

        APIHandler.shared.getAPIValues(
            type: GroceryListResponseModel.self,
            apiUrl: urlWithEmail,
            method: "GET"
        ) { result in
            DispatchQueue.main.async {
                switch result {
                case .success(let response):
                    items = response.data
                case .failure(let err):
                    alertMessage = "Failed to fetch items: \(err.localizedDescription)"
                    showAlert = true
                }
            }
        }
    }

    func toggleGroceryApiCall(id: Int, isChecked: Int) {
        let params: [String: Any] = [
            "id": id,
            "is_checked": isChecked
        ]

        APIHandler.shared.postAPIValues(
            type: GroceryResponseModel.self,
            apiUrl: APIList.update_groceryURl,
            method: "POST",
            formData: params
        ) { result in
            DispatchQueue.main.async {
                switch result {
                case .success(_):
                    fetchGroceriesApiCall()
                case .failure(let err):
                    alertMessage = "Failed to update item: \(err.localizedDescription)"
                    showAlert = true
                    fetchGroceriesApiCall()
                }
            }
        }
    }

    func deleteGroceryApiCall(id: Int) {
        let params: [String: Any] = ["id": id]

        APIHandler.shared.postAPIValues(
            type: GroceryResponseModel.self,
            apiUrl: APIList.delete_groceryURl,
            method: "POST",
            formData: params
        ) { result in
            DispatchQueue.main.async {
                switch result {
                case .success(_):
                    break // UI already updated optimistically
                case .failure(let err):
                    alertMessage = "Failed to delete item: \(err.localizedDescription)"
                    showAlert = true
                    fetchGroceriesApiCall()
                }
            }
        }
    }

    func deleteItem(at offsets: IndexSet) {
        for index in offsets {
            let item = items[index]
            items.remove(at: index)
            deleteGroceryApiCall(id: item.id)
        }
    }
}

// MARK: - Models

struct GroceryResponseModel: Codable {
    let status: Bool
    let message: String
    let data: [GroceryItem]? // handles single or multiple items

    private enum CodingKeys: String, CodingKey { case status, message, data }

    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        status = try container.decode(Bool.self, forKey: .status)
        message = try container.decode(String.self, forKey: .message)

        if let arr = try? container.decode([GroceryItem].self, forKey: .data) {
            data = arr
        } else if let single = try? container.decode(GroceryItem.self, forKey: .data) {
            data = [single]
        } else {
            data = nil
        }
    }
}

struct GroceryListResponseModel: Codable {
    let status: Bool
    let message: String
    let data: [GroceryItem]
}

struct GroceryItem: Codable, Identifiable {
    let id: Int
    var email: String?
    var name: String?
    var is_checked: Int?
    var created_at: String?

    var isCheckedBool: Bool { (is_checked ?? 0) == 1 }
}

// MARK: - Preview

struct GroceryListView_Previews: PreviewProvider {
    static var previews: some View {
        GroceryListView()
    }
}
