import SwiftUI

struct CreateEventPage: View {
    @Binding var selectedTab: BarButton  // ← Bind to homepage selectedTab
    @State private var eventName = ""
    @State private var date = Date()
    @State private var showAlert = false
    @State private var alertMessage = ""

    var body: some View {
        GeometryReader { geo in
            ZStack {
                Color(red: 0.95, green: 0.95, blue: 1.0)
                    .ignoresSafeArea()
                
                ScrollView(.vertical, showsIndicators: false) {   // ✅ Added ScrollView
                    VStack {
                        Spacer(minLength: geo.size.height * 0.1) // adds breathing room
                        
                        VStack(spacing: geo.size.height * 0.04) {
                            Text("Create Event")
                                .font(.system(size: geo.size.width * 0.10, weight: .bold, design: .serif))
                                .foregroundColor(Color.purple.opacity(0.8))
                                .padding(.bottom, geo.size.height * 0.02)
                            
                            CustomTextField(placeholder: "Event Name", text: $eventName, geo: geo)
                                .frame(width: geo.size.width * 0.75)
                            
                            CustomDateField(date: $date, geo: geo)
                                .frame(width: geo.size.width * 0.75)
                            
                            Button("Create") {
                                if eventName.isEmpty {
                                    alertMessage = "Please enter an event name"
                                    showAlert = true
                                } else {
                                    let formattedDate = formatDate(date)
                                    neweventdetailApiCall(event_name: eventName, event_date: formattedDate)
                                }
                            }
                            .frame(width: geo.size.width * 0.75, height: geo.size.height * 0.07)
                            .background(Color(red: 0.4, green: 0.2, blue: 0.8))
                            .foregroundColor(.white)
                            .cornerRadius(geo.size.height * 0.07 / 2)
                            .font(.system(size: geo.size.width * 0.08, weight: .semibold, design: .serif))
                            .padding(.top, geo.size.height * 0.02)
                        }
                        .padding(geo.size.width * 0.04)
                        .frame(width: geo.size.width * 0.9)
                        .background(
                            RoundedRectangle(cornerRadius: 25)
                                .fill(Color.white)
                                .shadow(color: Color(red: 0.4, green: 0.2, blue: 0.8).opacity(0.2), radius: 15, x: 0, y: 8)
                        )
                        .overlay(
                            RoundedRectangle(cornerRadius: 25)
                                .stroke(Color(red: 0.4, green: 0.2, blue: 0.8).opacity(0.3), lineWidth: 2)
                        )
                        
                        Spacer(minLength: geo.size.height * 0.3) // push bottom padding
                    }
                    .frame(minHeight: geo.size.height) // ensure full screen scroll
                }
            }
        }
        .alert("Message", isPresented: $showAlert) {
            Button("OK", role: .cancel) { }
        } message: {
            Text(alertMessage)
        }
    }
    
    func formatDate(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd"
        formatter.timeZone = TimeZone(secondsFromGMT: 0)
        return formatter.string(from: date)
    }
    
    func neweventdetailApiCall(event_name: String, event_date: String) {
        let param: [String: Any] = [
            "event_name": event_name,
            "event_date": event_date,
            "status": 0,
            "email": Manager.shared.email
        ]
        print("Creating event with params: \(param)")

        APIHandler.shared.postAPIValues(
            type: EventResponseModel.self,
            apiUrl: APIList.eventUrl,
            method: "POST",
            formData: param
        ) { result in
            DispatchQueue.main.async {
                switch result {
                case .success(let response):
                    print("API Response: \(response)")
                    selectedTab = .home
                case .failure(let err):
                    print("Error creating event: \(err)")
                    selectedTab = .home
                }
            }
        }
    }
}

// MARK: - Custom Fields
struct CustomTextField: View {
    var placeholder: String
    @Binding var text: String
    var geo: GeometryProxy

    var body: some View {
        TextField(placeholder, text: $text)
            .font(.system(size: geo.size.width * 0.06, design: .serif))
            .multilineTextAlignment(.center)
            .padding(.horizontal)
            .frame(height: geo.size.height * 0.055)
            .background(Color(red: 0.98, green: 0.98, blue: 1.0))
            .cornerRadius(geo.size.height * 0.055 / 2)
            .overlay(RoundedRectangle(cornerRadius: geo.size.height * 0.055 / 2)
                        .stroke(Color(red: 0.4, green: 0.2, blue: 0.8).opacity(0.3), lineWidth: 2))
    }
}

struct CustomDateField: View {
    @Binding var date: Date
    var geo: GeometryProxy

    var body: some View {
        HStack {
            Spacer()
            Image(systemName: "calendar")
                .font(.system(size: geo.size.width * 0.06))
                .foregroundColor(Color(red: 0.4, green: 0.2, blue: 0.8))
            DatePicker("", selection: $date, displayedComponents: .date)
                .labelsHidden()
                .font(.system(size: geo.size.width * 0.06, design: .serif))
                .accentColor(Color(red: 0.4, green: 0.2, blue: 0.8))
            Spacer()
        }
        .padding(.horizontal)
        .frame(height: geo.size.height * 0.055)
        .background(Color(red: 0.98, green: 0.98, blue: 1.0))
        .cornerRadius(geo.size.height * 0.055 / 2)
        .overlay(RoundedRectangle(cornerRadius: geo.size.height * 0.055 / 2)
                    .stroke(Color(red: 0.4, green: 0.2, blue: 0.8).opacity(0.3), lineWidth: 2))
    }
}

// MARK: - Preview
struct CreateEventPage_Previews: PreviewProvider {
    @State static var selectedTab: BarButton = .createEvent
    static var previews: some View {
        CreateEventPage(selectedTab: $selectedTab)
    }
}




