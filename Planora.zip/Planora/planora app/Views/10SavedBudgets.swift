import SwiftUI

// MARK: - Budget Data Model



// MARK: - Detail Row Component (white text)

struct DetailRow: View {
    let label: String
    let value: String

    var body: some View {
        HStack(alignment: .top) {
            Text("\(label):")
                .fontWeight(.medium)
                .foregroundColor(.white)
            Spacer()
            Text(value)
                .foregroundColor(.white.opacity(0.9))
                .multilineTextAlignment(.trailing)
        }
    }
}

// MARK: - Individual Budget Card View (purple-pink themed)

struct BudgetCardView: View {
    
   
    @State var budget: GetBudegtData?

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Text("Event #\(budget?.id ?? 0)")
                    .font(.title2)
                    .fontWeight(.bold)
                    .foregroundColor(.white)
                Spacer()
                Text("$\(budget?.totalCost ?? "0")")
                    .fontWeight(.bold)
                    .foregroundColor(.white)
            }

            DetailRow(label: "Guests", value: "\(budget?.totalGuests ?? 0)")
            DetailRow(label: "Price", value: budget?.priceLevel ?? "")
            DetailRow(label: "Dishes", value: changeValue(values: budget?.selectedDishes ?? ""))
            DetailRow(label: "Mandatory", value: changeValue(values: budget?.mandatoryItems ?? ""))

            HStack {
                Spacer()
              //  Text("Updated: \(budget.updatedAt)")
                    .font(.footnote)
                    .foregroundColor(.white.opacity(0.8))
            }
        }
        .padding()
        .background(
            LinearGradient(
                gradient: Gradient(colors: [Color.purple, Color.pink]),
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
        )
        .cornerRadius(20)
        .shadow(color: .pink.opacity(0.3), radius: 10, x: 0, y: 8)
        .padding(.horizontal)
        .padding(.vertical, 6)
        .onAppear {
            getAiFood()
        }
    }
        
     func getAiFood() {
       
         
         print("=====>>>>\(Manager.shared.eventID)")

        let param: [String: Any] = [
            "event_id": Manager.shared.eventID,
            
        ]
        APIHandler.shared.postAPIValues(type: GetBudegt.self, apiUrl: APIList.get_budgets, method: "POST", formData: param) { result in
            DispatchQueue.main.async {
                switch result {
                case .success(let response):
                    print(response)
                    budget = response.data
                  
                case .failure(let err):
                    print("API Error:", err)
                }
            }
        }
    }
    
    func changeValue(values:String)-> String {
        let jsonString = values

        if let data = jsonString.data(using: .utf8) {
            do {
                let dishArray = try JSONDecoder().decode([String].self, from: data)
                let dishString = dishArray.joined(separator: ",")
                print(dishString)  // Output: Tasty Stew, Grilled Salad
                return dishString
            } catch {
                print("Decoding failed: \(error)")
            }
        }
        return "no dish"

    }
}

// MARK: - Budget List View (scrollable)



// MARK: - Preview


struct BudgetCardView_Previews: PreviewProvider {
    static var previews: some View {
        BudgetCardView()
    }
}
