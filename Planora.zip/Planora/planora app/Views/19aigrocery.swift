import SwiftUI

struct AIGroceryListView: View {
    @AppStorage("groceryItems_\(Manager.shared.email)") private var savedItems: Data = Data()
    @State private var items: [AIGroceryItem] = []
    @State private var newDishName = ""
    @State private var showAlert = false
    @State private var alertMessage = ""

    var body: some View {
        GeometryReader { geometry in
            VStack {
                // Header
                Text("Grocery List - AI")
                    .font(.system(size: min(geometry.size.width * 0.08, 36), weight: .bold, design: .serif))
                    .italic()
                    .foregroundColor(.purple)
                    .padding(.top, geometry.size.height * 0.01)

                // Dish Entry Section
                HStack {
                    TextField("Enter Dish to generate", text: $newDishName)
                        .padding()
                        .background(Color(.systemGray6))
                        .cornerRadius(10)
                        .font(.system(size: 18))
                        .padding(.leading)

                    Button(action: {
                        if newDishName.isEmpty {
                            alertMessage = "Please enter a dish name"
                            showAlert = true
                        } else {
                            aigroceryApiCall(food_name: newDishName)
                        }
                    }) {
                        Text("Add")
                            .foregroundColor(.white)
                            .padding(.horizontal, 20)
                            .padding(.vertical, 12)
                            .background(Color.purple)
                            .cornerRadius(10)
                    }
                    .padding(.trailing)
                }

                // Grocery Items List
                if items.isEmpty {
                    Spacer()
                    VStack {
                        Image(systemName: "cart")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 100, height: 100)
                            .foregroundColor(.gray)
                        Text("Your grocery list is empty.")
                            .foregroundColor(.gray)
                            .font(.headline)
                            .padding(.top, 8)
                    }
                    Spacer()
                } else {
                    List {
                        ForEach(items) { item in
                            HStack {
                                // Checkbox
                                Button(action: {
                                    if let idx = items.firstIndex(where: { $0.id == item.id }) {
                                        items[idx].isChecked.toggle()
                                        saveItems()   // persist change
                                    }
                                }) {
                                    Image(systemName: item.isChecked ? "checkmark.square.fill" : "square")
                                        .resizable()
                                        .frame(width: 24, height: 24)
                                        .foregroundColor(.purple)
                                }
                                .buttonStyle(BorderlessButtonStyle())

                                // Item name
                                Text(item.name)
                                    .foregroundColor(.black)
                                    .font(.system(size: 18, design: .serif))
                                    .italic()
                                    .strikethrough(item.isChecked)

                                Spacer()

                                // Trash button
                                Button(action: {
                                    if let idx = items.firstIndex(where: { $0.id == item.id }) {
                                        items.remove(at: idx)
                                        saveItems()   // persist change
                                    }
                                }) {
                                    Image(systemName: "trash")
                                        .foregroundColor(.red)
                                        .padding(6)
                                }
                                .buttonStyle(BorderlessButtonStyle())
                            }
                        }
                        .onDelete(perform: deleteItem)
                    }
                    .listStyle(PlainListStyle())
                }

                Spacer()
            }
            .background(Color(.systemGray5).ignoresSafeArea())
            .onAppear(perform: loadItems)   // 👈 load saved items on view open
        }
        .alert("Message", isPresented: $showAlert) {
            Button("OK", role: .cancel) { }
        } message: {
            Text(alertMessage)
        }
    }

    // MARK: - API Call (AI Integration)
//    func aigroceryApiCall(food_name: String) {
//        let param = ["dish": food_name]
//
//        APIHandler.shared.postAPIValues(
//            type: AIGroceryResponse.self,
//            apiUrl: APIList.aigrocery,
//            method: "POST",
//            formData: param
//        ) { result in
//            DispatchQueue.main.async {
//                switch result {
//                case .success(let response):
//                    print("AI Grocery Response:", response)
//
//                    if let rawString = response.data.first {
//                        let ingredients = rawString.split(separator: ";").map { String($0).trimmingCharacters(in: .whitespaces) }
//                        
//                        // ✅ Append instead of replacing
//                        let newItems = ingredients.map { AIGroceryItem(name: $0) }
//
//                        // Deduplicate: keep only unique names
//                        let existingNames = Set(self.items.map { $0.name.lowercased() })
//                        let filtered = newItems.filter { !existingNames.contains($0.name.lowercased()) }
//
//                        self.items.append(contentsOf: filtered)
//                        saveItems()
//   // persist
//                    }
//
//                    self.newDishName = ""
//                case .failure(let error):
//                    print(error)
//                    self.alertMessage = "Failed to fetch AI grocery list: \(error.localizedDescription)"
//                    self.showAlert = true
//                }
//            }
//        }
//    }
    
    func aigroceryApiCall(food_name: String) {
        let param = ["dish": food_name]

        APIHandler.shared.postAPIValues(
            type: AIGroceryResponse.self,
            apiUrl: APIList.aigrocery,
            method: "POST",
            formData: param
        ) { result in
            DispatchQueue.main.async {
                switch result {
                case .success(let response):
                    print("AI Grocery Response:", response)

                    // ✅ Use entire response.data array
                    let ingredients = response.data.map { $0.trimmingCharacters(in: .whitespaces) }

                    let newItems = ingredients.map { AIGroceryItem(name: $0) }

                    let existingNames = Set(self.items.map { $0.name.lowercased() })
                    let filtered = newItems.filter { !existingNames.contains($0.name.lowercased()) }

                    self.items.append(contentsOf: filtered)
                    saveItems()

                    self.newDishName = ""
                case .failure(let error):
                    print(error)
                    self.alertMessage = "Failed to fetch AI grocery list: \(error.localizedDescription)"
                    self.showAlert = true
                }
            }
        }
    }


    func deleteItem(at offsets: IndexSet) {
        items.remove(atOffsets: offsets)
        saveItems()
    }

    // MARK: - Persistence
    func saveItems() {
        if let encoded = try? JSONEncoder().encode(items) {
            savedItems = encoded
        }
    }

    func loadItems() {
        if let decoded = try? JSONDecoder().decode([AIGroceryItem].self, from: savedItems) {
            items = decoded
        }
    }
}

// MARK: - Models
struct AIGroceryResponse: Codable {
    let status: Bool
    let message: String
    let data: [String]
}

struct AIGroceryItem: Identifiable, Codable {
    let id: UUID
    let name: String
    var isChecked: Bool
    
    init(id: UUID = UUID(), name: String, isChecked: Bool = false) {
        self.id = id
        self.name = name
        self.isChecked = isChecked
    }
}

// MARK: - Preview
struct AIGroceryListView_Previews: PreviewProvider {
    static var previews: some View {
        AIGroceryListView()
    }
}

