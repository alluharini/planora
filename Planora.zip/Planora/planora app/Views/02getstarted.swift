import SwiftUI

struct getstarted: View {
    var body: some View {
        NavigationView {
            ZStack {
                // Fullscreen Background Image with Gradient
                Image("party")
                    .resizable()
                    .scaledToFill()
                    .ignoresSafeArea() // Ensures full screen coverage
                    .overlay(
                        LinearGradient(
                            gradient: Gradient(colors: [
                                Color.purple.opacity(0.7),
                                Color.purple.opacity(0.5),
                                Color.purple.opacity(0.3)
                            ]),
                            startPoint: .top,
                            endPoint: .bottom
                        )
                    )

                GeometryReader { geometry in
                    VStack(spacing: geometry.size.height * 0.03) {
                        NavigationLink(destination: loginpage()) {
                            HStack {
                                Image(systemName: "person.fill")
                                    .font(.system(size: geometry.size.width * 0.05))
                                Text("Login")
                                    .font(.system(size: geometry.size.width * 0.05, weight: .semibold))
                            }
                            .foregroundColor(.white)
                            .frame(width: geometry.size.width * 0.7, height: geometry.size.height * 0.07)
                            .background(
                                RoundedRectangle(cornerRadius: 15)
                                    .fill(.ultraThinMaterial)
                            )
                            .overlay(
                                RoundedRectangle(cornerRadius: 15)
                                    .stroke(Color.white.opacity(0.5), lineWidth: 1)
                            )
                            .shadow(color: .black.opacity(0.2), radius: 10, x: 0, y: 5)
                        }

                        NavigationLink(destination: signuppage()) {
                            HStack {
                                Image(systemName: "person.badge.plus.fill")
                                    .font(.system(size: geometry.size.width * 0.05))
                                Text("Sign Up")
                                    .font(.system(size: geometry.size.width * 0.05, weight: .semibold))
                            }
                            .foregroundColor(.white)
                            .frame(width: geometry.size.width * 0.7, height: geometry.size.height * 0.07)
                            .background(
                                RoundedRectangle(cornerRadius: 15)
                                    .fill(.ultraThinMaterial)
                            )
                            .overlay(
                                RoundedRectangle(cornerRadius: 15)
                                    .stroke(Color.white.opacity(0.5), lineWidth: 1)
                            )
                            .shadow(color: .black.opacity(0.2), radius: 10, x: 0, y: 5)
                        }
                    }
                    .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .center)
                }
            }
            .navigationBarHidden(true)
        }
        .navigationViewStyle(StackNavigationViewStyle())
        .onAppear {
            //calls()
        }
    }
    
    func calls() {
        
        
        // ✅ Your API URL (must include http://)
        let urlString = "http://180.235.121.245:4032/recommendations"

        guard let url = URL(string: urlString) else {
            print("❌ Invalid URL")
            return
        }

        // Create a POST request
        var request = URLRequest(url: url)
        request.httpMethod = "POST"

        // If you need headers
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")

        // If your API requires a body (example JSON)
        let body: [String: Any] = [
            "total_guests": "10",
            "cuisines": "indian",
            "diets": "vegetarian",
            "price_level": "medium"
           
        ]

        do {
            request.httpBody = try JSONSerialization.data(withJSONObject: body, options: [])
        } catch {
            print("❌ Error encoding JSON body: \(error)")
            return
        }

        // Send request
        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                print("❌ API Error:", error)
                return
            }
            
            if let httpResponse = response as? HTTPURLResponse {
                print("✅ Status Code:", httpResponse.statusCode)
            }
            
            guard let data = data else {
                print("❌ No data received")
                return
            }
            
            // Try to decode response as JSON
            do {
                if let json = try JSONSerialization.jsonObject(with: data, options: []) as? [String: Any] {
                    print("✅ API Response:", json)
                } else {
                    print("⚠️ Response not JSON:", String(data: data, encoding: .utf8) ?? "")
                }
            } catch {
                print("❌ JSON parse error:", error)
            }
        }

        task.resume()

    }
    
}

struct GetStarted_Previews: PreviewProvider {
    static var previews: some View {
        getstarted()
            .previewDevice("iPhone 16 Pro")
    }
}

