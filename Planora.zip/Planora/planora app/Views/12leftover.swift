import SwiftUI

struct LeftoverIdeas: View {
    @State private var foodInput: String = ""
    @State private var navigate = false

    var body: some View {
        NavigationStack {
            ZStack {
                // Background gradient
                LinearGradient(colors: [Color.purple.opacity(0.3), Color.pink.opacity(0.3)],
                               startPoint: .topLeading,
                               endPoint: .bottomTrailing)
                    .ignoresSafeArea()

                VStack {
                    Spacer()

                    // Glassy form card
                    VStack(spacing: 25) {
                        Text("Leftover Ideas")
                            .font(.system(size: 36, weight: .bold, design: .serif))
                            .foregroundStyle(
                                LinearGradient(colors: [.purple, .pink],
                                               startPoint: .leading,
                                               endPoint: .trailing)
                            )

                        Text("Enter the food you want to reuse")
                            .font(.headline)
                            .foregroundColor(.gray)
                            .italic()
                            .multilineTextAlignment(.center)

                        TextField("Add Food (e.g., rice, chicken)", text: $foodInput)
                            .padding()
                            .background(Color.white.opacity(0.8))
                            .cornerRadius(12)
                            .overlay(
                                RoundedRectangle(cornerRadius: 12)
                                    .stroke(Color.purple.opacity(0.4), lineWidth: 1)
                            )

                        Button(action: {
                            leftoverfoodideaApiCall(food_name: foodInput)
                            Manager.shared.foodInpu = foodInput
                            navigate = true
                        }) {
                            Text("Get Ideas")
                                .font(.headline.bold())
                                .frame(maxWidth: .infinity)
                                .frame(height: 50)
                                .background(
                                    LinearGradient(colors: [Color.purple, Color.pink],
                                                   startPoint: .leading,
                                                   endPoint: .trailing)
                                )
                                .foregroundColor(.white)
                                .cornerRadius(12)
                                .shadow(radius: 5)
                        }
                    }
                    .padding()
                    .background(
                        RoundedRectangle(cornerRadius: 25)
                            .fill(.ultraThinMaterial)
                            .shadow(color: .purple.opacity(0.2), radius: 15, x: 0, y: 10)
                    )
                    .padding(.horizontal, 24)

                    Spacer()
                }
            }
            .navigationDestination(isPresented: $navigate) {
                ideaView()
            }
        }
    }

    func leftoverfoodideaApiCall(food_name: String) {
        let param = ["food_name": food_name]
        APIHandler.shared.postAPIValues(
            type: LeftoverfoodResponseModel.self,
            apiUrl: APIList.foofLeftOver,
            method: "POST",
            formData: param
        ) { result in
            DispatchQueue.main.async {
                switch result {
                case .success(let response):
                    print(response)
                case .failure(let error):
                    print(error)
                }
            }
        }
    }
}

struct LeftoverIdeas_Previews: PreviewProvider {
    static var previews: some View {
        LeftoverIdeas()
    }
}

