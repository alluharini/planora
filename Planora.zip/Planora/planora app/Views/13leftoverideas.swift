import SwiftUI

struct LeftoverIdeasView: View {
    // Sample dishes data
    @State var dishes = [String]()
    
    var body: some View {
        GeometryReader { geometry in
            ScrollView {
                VStack(spacing: geometry.size.height * 0.02) {
                    // Title
                    Text("Leftover Ideas")
                        .font(.system(size: min(geometry.size.width * 0.1, 56), weight: .medium, design: .serif))
                        .foregroundColor(Color(red: 72/255, green: 61/255, blue: 139/255))
                        .italic()
                        .frame(maxWidth: .infinity, alignment: .center)
                        .padding(.top, geometry.size.height * 0.0001)

                    // Subtitle
                    Text("You can make these dishes with the leftovers")
                        .font(.system(size: min(geometry.size.width * 0.045, 28), weight: .medium, design: .serif))
                        .italic()
                        .multilineTextAlignment(.center)
                        .padding(.horizontal)
                        .frame(maxWidth: .infinity)

                    // Dishes recommendations box
                    VStack {
                        Text("                     Recommended Dishes                   ")
                            .font(.system(size: min(geometry.size.width * 0.05, 28), weight: .medium, design: .serif))
                            .italic()
                            .foregroundColor(.purple)
                            .padding(.top, geometry.size.height * 0.011)

                        ScrollView {
                            VStack(spacing: geometry.size.height * 0.015) {
                                ForEach(dishes, id: \.self) { dish in
                                    HStack {
                                        Image(systemName: "fork.knife")
                                            .foregroundColor(Color(red: 72/255, green: 61/255, blue: 139/255))
                                            .font(.system(size: min(geometry.size.width * 0.05, 28)))
                                        Text(dish)
                                            .font(.system(size: min(geometry.size.width * 0.05, 28)))
                                        Spacer()
                                    }
                                    .padding(.horizontal, geometry.size.width * 0.03)
                                }
                            }
                        }
                        .padding(.vertical, geometry.size.height * 0.01)
                    }
                    .background(Color(.systemGray4))
                    .cornerRadius(40)
                    .frame(height: geometry.size.height * 0.37)
                    .padding(.horizontal, geometry.size.width * 0.03)

                    // Or else text
                    Text("Or else, there's always a beautiful option... share your leftovers and feed someone in need.")
                        .font(.system(size: min(geometry.size.width * 0.04, 28), weight: .medium, design: .serif))
                        .italic()
                        .multilineTextAlignment(.center)
                        .padding(.horizontal)
                        .frame(minHeight: geometry.size.height * 0.001)

                    // Food donation image
                    Image("food")
                        .resizable()
                        .aspectRatio(contentMode: .fill)
                        .frame(height: geometry.size.height * 0.37)
                        .clipShape(RoundedRectangle(cornerRadius: 40))
                        .padding(.horizontal, geometry.size.width * 0.04)

                    Spacer()
                }
                
                .padding(.top, geometry.size.height * 0.01)
            }
            .onAppear {
                getLeftOverFood()
                }
            .background(Color.white)
            
            
            
        }
        
        
        

    }
    
     func getLeftOverFood() {
        
        let param = ["ingredient": Manager.shared.foodInpu]
        
        APIHandler.shared.postAPIValues(type: LeftOverFood.self, apiUrl: APIList.foofLeftOver, method: "POST", formData: param) { result in
            DispatchQueue.main.sync {
                switch result {
                case .success(let response):
                    print(response)
                    dishes = response.data
                case .failure(let err):
                    print(err)
                }
            }
            
        }
    }
}

struct LeftoverIdeasView_Previews: PreviewProvider {
    static var previews: some View {
        Group {
            LeftoverIdeasView()
                .previewDevice("iPad Pro (12.9-inch) (6th generation)")
            LeftoverIdeasView()
                .previewDevice("iPhone 14 Pro")
        }
    }
}


