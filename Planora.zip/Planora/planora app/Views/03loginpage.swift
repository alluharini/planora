//integration done
//page done no changes
import SwiftUI

struct loginpage: View {
    @State private var email: String = ""
    @State private var password: String = ""
    @State private var isAnimating = false
    @State private var navigateToSignup = false
    @State private var navigateToHomepage = false
    
    @State private var showAlert = false
    @State private var alertMessage = ""
    @State private var isLoginSuccessful = false
    @State private var isEmpty = false

    var body: some View {
        NavigationStack {
            ZStack {
                Image("background")
                    .resizable()
                    .scaledToFill()
                    .ignoresSafeArea()
                    .blur(radius: 4)
                
                Color.black.opacity(0.4)
                    .ignoresSafeArea()
                
                GeometryReader { geometry in
                    VStack {
                        Spacer()
                        VStack(spacing: 25) {
                            Text("Welcome Back")
                                .font(.system(size: 36, weight: .bold))
                                .foregroundColor(.blue)
                                .shadow(radius: 2)
                                .shadow(color: .black.opacity(0.2), radius: 8, x: 0, y: 4)
                                .opacity(isAnimating ? 1 : 0)
                                .offset(y: isAnimating ? 0 : 20)
                            
                            Text("Sign in to continue")
                                .font(.title3)
                                .fontWeight(.medium)
                                .foregroundColor(.white)
                                .padding(.top, -10)
                                .opacity(isAnimating ? 1 : 0)
                                .offset(y: isAnimating ? 0 : 20)
                            
                            // Input fields container
                            VStack(spacing: 16) {
                                // Email field
                                HStack {
                                    Image(systemName: "envelope.fill")
                                        .foregroundColor(.gray)
                                        .frame(width: 20)
                                    TextField("Email", text: $email)
                                        .textContentType(.emailAddress)
                                        .keyboardType(.emailAddress)
                                        .autocapitalization(.none)
                                        .foregroundColor(.black)
                                }
                                .padding()
                                .background(Color.white.opacity(0.95))
                                .overlay(
                                    RoundedRectangle(cornerRadius: 12)
                                        .stroke(Color.gray.opacity(0.3), lineWidth: 1)
                                )
                                .frame(maxWidth: 340)
                                .shadow(color: Color.black.opacity(0.04), radius: 6, x: 0, y: 2)
                                
                                // Password field
                                HStack {
                                    Image(systemName: "lock.fill")
                                        .foregroundColor(.gray)
                                        .frame(width: 20)
                                    SecureField("Password", text: $password)
                                        .textContentType(.password)
                                        .autocapitalization(.none)
                                        .foregroundColor(.black)
                                }
                                .padding()
                                .background(Color.white.opacity(0.95))
                                .overlay(
                                    RoundedRectangle(cornerRadius: 12)
                                        .stroke(Color.gray.opacity(0.3), lineWidth: 1)
                                )
                                .frame(maxWidth: 340)
                                .shadow(color: Color.black.opacity(0.04), radius: 6, x: 0, y: 2)
                            }
                            .opacity(isAnimating ? 1 : 0)
                            .offset(y: isAnimating ? 0 : 20)
                            // Login button
                            Button(action: {
                                // Login action
                                guard !email.isEmpty, !password.isEmpty else {
                                    isEmpty = true
                                    return }
                                loginApiCall(email: email, password: password)
                                
                            }) {
                                Text("Sign In")
                                    .font(.headline)
                                    .foregroundColor(.white)
                                    .frame(maxWidth: 340)
                                    .frame(height: 50)
                                    .background(
                                        LinearGradient(gradient: Gradient(colors: [
                                            Color(red: 0.4, green: 0.2, blue: 0.8),
                                            Color(red: 0.3, green: 0.3, blue: 0.9)
                                        ]), startPoint: .leading, endPoint: .trailing)
                                    )
                                    .cornerRadius(12)
                                    .shadow(color: Color.black.opacity(0.08), radius: 8, x: 0, y: 3)
                            }
                            .padding(.top, 6)
                            .opacity(isAnimating ? 1 : 0)
                            .offset(y: isAnimating ? 0 : 20)
                            
                            // Register link
                            HStack {
                                Text("Don't have an account?")
                                    .foregroundColor(.white)
                                NavigationLink(destination: signuppage()) {
                                    Text("Register")
                                        .foregroundColor(.white)
                                        .fontWeight(.bold)
                                }
                            }
                            .padding(.top, 10)
                            .opacity(isAnimating ? 1 : 0)
                            .offset(y: isAnimating ? 0 : 20)
                        }
                        Spacer()
                    }
                    .frame(width: geometry.size.width, height: geometry.size.height)
                }
            }
            .navigationBarHidden(true)
            .fullScreenCover(isPresented: $navigateToHomepage) {
                homepage()
            }
        }
        .onAppear {
            withAnimation(.easeOut(duration: 0.8)) {
                isAnimating = true
            }
        }
        
        .alert(isPresented: $showAlert) {
            Alert(
                title: Text(isLoginSuccessful ? "Success" : "Error"),
                message: Text(alertMessage),
                dismissButton: .default(Text("OK"))
            )
            
        }
        .alert(isPresented: $isEmpty) {
            Alert(title: Text("Warning"), message: Text("Please fill all the fields"))
        }
    }
    
    func loginApiCall(email:String, password: String) {
        
        let param = ["email":email,"password":password]
        
        APIHandler.shared.postAPIValues(type: LoginResponseModel.self, apiUrl: APIList.loginUrl, method: "POST", formData: param) { result in
            DispatchQueue.main.sync {
                switch result {
                case .success(let response):
                    print(response)
                    Manager.shared.email = email
                    navigateToHomepage = true
                case .failure(let err):
                    print(err)
                }
            }
            
        }
    }
}

struct loginpage_Previews: PreviewProvider {
    static var previews: some View {
        loginpage()
    }
}




