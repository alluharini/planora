import SwiftUI

struct PreferenceView: View {
    @State private var totalGuests = ""
    @State private var selectedEventType = "Select"
    @State private var selectedCuisines: Set<String> = []
    @State private var selectedDietaries: Set<String> = []
    @State private var selectedPriceLevel = ""
    @State private var shouldNavigate = false
    @State private var showSavedBudgets = false
    @State private var getBudgetData: GetBudegtData? = nil
    

    let eventTypes = ["Select", "Birthday", "get to gather", "meeting", "Casualparty"]
    let cuisines = ["Italian", "Indian", "Chinese", "Mexican", "American", "Thai", "Korean"]
    let dietaryOptions = ["Vegetarian", "Vegan", "Dairy-Free", "non-vegetarian", "Nut-free"]
    let priceLevels = ["basic", "medium", "premium"]

    var body: some View {
        ZStack {
            LinearGradient(gradient: Gradient(colors: [Color.purple.opacity(0.1), Color.white]),
                           startPoint: .top, endPoint: .bottom)
                .ignoresSafeArea()


                ScrollView {
                    VStack(spacing: 25) {
                        titleSection()
                        guestSection()
                        eventTypeSection()
                        cuisineSection()
                        dietarySection()
                        priceLevelSection()
                        navigationLinkHidden()
                        actionButton()
                    }
                    .padding(.bottom, 30)
                }

                NavigationLink(destination: BudgetCardView(budget: nil), isActive: $showSavedBudgets) {
                    EmptyView()
                }
              
            }
        }
       

    // MARK: - Subviews

    @ViewBuilder
    private func titleSection() -> some View {
        HStack {
            Text("Event Dish Recommender")
                .font(.system(size: 22, weight: .bold, design: .rounded))
                .foregroundColor(.purple)
                .shadow(color: .purple.opacity(0.2), radius: 1, x: 0, y: 1)

            Spacer()

            Button(action: {
                showSavedBudgets = true
            }) {
                HStack(spacing: 6) {
                    Image(systemName: "banknote.fill")
                    Text("Saved Budgets")
                }
                .padding(.horizontal, 12)
                .padding(.vertical, 6)
                .background(Color.purple)
                .foregroundColor(.white)
                .font(.system(size: 14, weight: .semibold))
                .clipShape(Capsule())
                .shadow(color: Color.purple.opacity(0.3), radius: 4, x: 0, y: 2)
            }
        }
        .padding(.top, 30)
        .padding(.horizontal)
    }

    @ViewBuilder
    private func guestSection() -> some View {
        VStack(alignment: .leading, spacing: 10) {
            Label("Number of Guests", systemImage: "person.3.fill")
                .font(.headline)
                .foregroundColor(.purple)

            TextField("Enter total guests", text: $totalGuests)
                .keyboardType(.numberPad)
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .padding()
                .background(
                    RoundedRectangle(cornerRadius: 15)
                        .fill(Color.white)
                        .shadow(color: .purple.opacity(0.1), radius: 5, x: 0, y: 2)
                )
        }
        .padding(.horizontal)
    }

    @ViewBuilder
    private func eventTypeSection() -> some View {
        VStack(alignment: .leading, spacing: 10) {
            Label("Event Type", systemImage: "calendar")
                .font(.headline)
                .foregroundColor(.purple)

            Picker("Event Type", selection: $selectedEventType) {
                ForEach(eventTypes, id: \.self) { Text($0) }
            }
            .pickerStyle(.menu)
            .padding()
            .background(
                RoundedRectangle(cornerRadius: 15)
                    .fill(Color.white)
                    .shadow(color: .purple.opacity(0.1), radius: 5, x: 0, y: 2)
            )
        }
        .padding(.horizontal)
    }

    @ViewBuilder
    private func cuisineSection() -> some View {
        VStack(alignment: .leading, spacing: 10) {
            Label("Preferred Cuisine", systemImage: "fork.knife")
                .font(.headline)
                .foregroundColor(.purple)

            LazyVGrid(columns: [GridItem(.adaptive(minimum: 100))], spacing: 10) {
                ForEach(cuisines, id: \.self) { cuisine in
                    Button(action: {
                        if selectedCuisines.contains(cuisine) {
                            selectedCuisines.remove(cuisine)
                        } else {
                            selectedCuisines.insert(cuisine)
                        }
                    }) {
                        Text(cuisine)
                            .fontWeight(selectedCuisines.contains(cuisine) ? .bold : .regular)
                            .padding(8)
                            .frame(maxWidth: .infinity)
                            .background(selectedCuisines.contains(cuisine) ? Color.purple.opacity(0.7) : Color.gray.opacity(0.2))
                            .foregroundColor(selectedCuisines.contains(cuisine) ? .white : .primary)
                            .cornerRadius(10)
                    }
                }
            }
            .padding(.top, 5)
        }
        .padding(.horizontal)
    }

    @ViewBuilder
    private func dietarySection() -> some View {
        VStack(alignment: .leading, spacing: 10) {
            Label("Dietary Preferences", systemImage: "leaf.fill")
                .font(.headline)
                .foregroundColor(.purple)

            LazyVGrid(columns: [GridItem(.adaptive(minimum: 120))], spacing: 10) {
                ForEach(dietaryOptions, id: \.self) { dietary in
                    Button(action: {
                        if selectedDietaries.contains(dietary) {
                            selectedDietaries.remove(dietary)
                        } else {
                            selectedDietaries.insert(dietary)
                        }
                    }) {
                        Text(dietary.capitalized)
                            .fontWeight(selectedDietaries.contains(dietary) ? .bold : .regular)
                            .padding(8)
                            .frame(maxWidth: .infinity)
                            .background(selectedDietaries.contains(dietary) ? Color.purple.opacity(0.7) : Color.gray.opacity(0.2))
                            .foregroundColor(selectedDietaries.contains(dietary) ? .white : .primary)
                            .cornerRadius(10)
                    }
                }
            }
            .padding(.top, 5)
        }
        .padding(.horizontal)
    }

    @ViewBuilder
    private func priceLevelSection() -> some View {
        VStack(alignment: .leading, spacing: 10) {
            Label("Price Range", systemImage: "dollarsign.circle.fill")
                .font(.headline)
                .foregroundColor(.purple)

            HStack(spacing: 10) {
                ForEach(priceLevels, id: \.self) { price in
                    Button(action: {
                        selectedPriceLevel = price
                    }) {
                        Text(price.capitalized)
                            .fontWeight(selectedPriceLevel == price ? .bold : .regular)
                            .padding(8)
                            .frame(maxWidth: .infinity)
                            .background(selectedPriceLevel == price ? Color.purple.opacity(0.7) : Color.gray.opacity(0.2))
                            .foregroundColor(selectedPriceLevel == price ? .white : .primary)
                            .cornerRadius(10)
                    }
                }
            }
            .padding()
            .background(
                RoundedRectangle(cornerRadius: 15)
                    .fill(Color.white)
                    .shadow(color: .purple.opacity(0.1), radius: 5, x: 0, y: 2)
            )
        }
        .padding(.horizontal)
    }

    @ViewBuilder
    private func navigationLinkHidden() -> some View {
        NavigationLink(destination: DishSelectionView(), isActive: $shouldNavigate) {
            EmptyView()
        }
    }

    @ViewBuilder
    private func actionButton() -> some View {
        Button(action: {
            getAiFood()
        }) {
            HStack {
                Text("Show Recommended Dishes")
                    .font(.headline)
                Image(systemName: "arrow.right.circle.fill")
            }
            .frame(maxWidth: .infinity)
            .padding()
            .background(
                LinearGradient(gradient: Gradient(colors: [Color.purple, Color.purple.opacity(0.8)]),
                               startPoint: .leading, endPoint: .trailing)
            )
            .foregroundColor(.white)
            .cornerRadius(15)
            .shadow(color: .purple.opacity(0.3), radius: 5, x: 0, y: 3)
        }
        .disabled(totalGuests.isEmpty)
        .padding(.horizontal)
        .padding(.top, 10)
    }

    private func getAiFood() {
        Manager.shared.totalGuest = totalGuests
        Manager.shared.selectedCuisines = selectedCuisines.joined(separator: ",")
        Manager.shared.selectedDietary = selectedDietaries.joined(separator: ",")
        Manager.shared.selectedPriceLevel = selectedPriceLevel
        Manager.shared.selectedEventType = selectedEventType

        let param: [String: Any] = [
            "total_guests": totalGuests,
            "cuisines": selectedCuisines.joined(separator: ","),
            "diets": selectedDietaries.joined(separator: ","),
            "price_level": selectedPriceLevel
        ]
        APIHandler.shared.postAPIValues(type: AIfood.self, apiUrl: APIList.foodai, method: "POST", formData: param) { result in
            DispatchQueue.main.async {
                switch result {
                case .success(let response):
                    print(response)
                    Manager.shared.recommendedDish = response.data.recommendedDishes 
                    self.shouldNavigate = true
                case .failure(let err):
                    print("API Error:", err)
                }
            }
        }
    }
}


// Placeholder for SavedBudgetsView
struct SavedBudgetsView: View {
    var body: some View {
        Text("No budgets saved")
            .font(.title)
            .foregroundColor(.purple)
            .padding()
    }
}

struct PreferenceView_Previews: PreviewProvider {
    static var previews: some View {
        PreferenceView()
    }
}

