import SwiftUI

struct SettingsView: View {
    @State private var notificationsEnabled = true
    @State private var showingDeleteConfirmation = false
    @State private var showingLogoutConfirmation = false
    @State private var navigateToWelcome = false
    @State private var path = NavigationPath() // <-- NavigationPath added

    var body: some View {
        NavigationStack(path: $path) { // <-- Use path
            VStack(spacing: 0) {
                
                // Custom header
                HStack {
                    Text("Settings")
                        .font(.largeTitle.bold())
                        .padding(.leading, 20)
                        .padding(.top, -13)
                    Spacer()
                }
                .padding(.top, 10)
                .padding(.bottom, 5)
                .background(Color.white)
                .shadow(color: Color.black.opacity(0.05), radius: 1, x: 0, y: 1)
                
                List {
                    // App Information Section
                    Section(header: Text("App Information")) {
                        NavigationLink(destination: HowToUseView()) {
                            Label("How to Use", systemImage: "questionmark.circle")
                        }

                        NavigationLink(destination: FeedbackView()) {
                            Label("Send Feedback", systemImage: "envelope")
                        }

                        NavigationLink(destination: ContactUsView()) {
                            Label("Contact Us", systemImage: "person.circle")
                        }
                    }

                    // Preferences Section
                    Section(header: Text("Preferences")) {
                        Toggle(isOn: $notificationsEnabled) {
                            Label("Notifications", systemImage: "bell")
                        }

                        NavigationLink(destination: LanguageSettingsView()) {
                            Label("Language", systemImage: "globe")
                        }
                    }

                    // Account Section
                    Section(header: Text("Account")) {
                        Button(action: {
                            showingLogoutConfirmation = true
                        }) {
                            Label("Logout", systemImage: "arrow.right.square")
                                .foregroundColor(.red)
                        }

                        Button(action: {
                            showingDeleteConfirmation = true
                        }) {
                            Label("Delete Account", systemImage: "person.crop.circle.badge.minus")
                                .foregroundColor(.red)
                        }
                    }

                    // About Section
                    Section(header: Text("About")) {
                        NavigationLink(destination: TermsOfServiceView()) {
                            Label("Terms of Service", systemImage: "doc.text")
                        }

                        NavigationLink(destination: PrivacyPolicyView()) {
                            Label("Privacy Policy", systemImage: "hand.raised")
                        }

                        HStack {
                            Label("Version", systemImage: "info.circle")
                            Spacer()
                            Text("1.0.0")
                                .foregroundColor(.gray)
                        }
                    }
                }
            }
            .background(Color.white)
            .navigationBarHidden(true)
            // Logout Alert
            .alert("Logout", isPresented: $showingLogoutConfirmation) {
                Button("Cancel", role: .cancel) {}
                Button("Logout", role: .destructive) {
                    UserDefaults.standard.set("", forKey: "username")
                    path.removeLast(path.count) // <-- clear stack
                    navigateToWelcome = true
                }
            } message: {
                Text("Are you sure you want to logout?")
            }
            // Delete Account Alert
            .alert("Delete Account", isPresented: $showingDeleteConfirmation) {
                Button("Cancel", role: .cancel) {}
                Button("Delete", role: .destructive) {
                    UserDefaults.standard.set("", forKey: "username")
                    path.removeLast(path.count) // <-- clear stack
                    navigateToWelcome = true
                }
            } message: {
                Text("Are you sure you want to delete your account? This action cannot be undone.")
            }
            // Navigate to welcome page after stack clear
            .navigationDestination(isPresented: $navigateToWelcome) {
                welcomepage()
            }
        }
    }
}

#Preview {
    SettingsView()
}
