import SwiftUI

struct PartyNotes: View {
    @State private var noteText: String = ""
    @State private var notes: [NoteItem] = []
    @State private var showAlert = false
    @State private var alertMessage = ""
    
    var body: some View {
        GeometryReader { geometry in
            VStack(spacing: 0) {
                
                // Header
                ZStack {
                    LinearGradient(colors: [Color.purple.opacity(0.7), Color.pink.opacity(0.6)],
                                   startPoint: .topLeading,
                                   endPoint: .bottomTrailing)
                        .frame(height: geometry.size.height * 0.09)
                        .clipShape(RoundedRectangle(cornerRadius: 30, style: .continuous))
                        .shadow(radius: 3)
                    
                    HStack {
                        Text("🎉 Party Notes")
                            .font(.system(size: 20, weight: .bold, design: .serif))
                            .italic()
                            .foregroundColor(.white)
                        Spacer()
                        Image(systemName: "note.text")
                            .font(.system(size: 22))
                            .foregroundColor(.white.opacity(0.9))
                    }
                    .padding(.horizontal)
                }
                .padding(.bottom, 20)
                
                // TextEditor
                VStack(alignment: .leading, spacing: 10) {
                    ZStack(alignment: .topLeading) {
                        RoundedRectangle(cornerRadius: 18)
                            .stroke(LinearGradient(colors: [.purple.opacity(0.4), .pink.opacity(0.4)],
                                                   startPoint: .topLeading,
                                                   endPoint: .bottomTrailing), lineWidth: 1.5)
                            .background(
                                RoundedRectangle(cornerRadius: 18)
                                    .fill(Color.white)
                                    .shadow(color: .gray.opacity(0.1), radius: 4, x: 0, y: 2)
                            )
                        
                        TextEditor(text: $noteText)
                            .padding(12)
                            .frame(height: 160)
                            .font(.system(size: 16, weight: .regular, design: .serif))
                            .foregroundColor(.black)
                            .cornerRadius(18)
                        
                        if noteText.isEmpty {
                            Text("✍️ Write your thoughts here...")
                                .foregroundColor(.gray.opacity(0.6))
                                .italic()
                                .padding(.horizontal, 20)
                                .padding(.top, 16)
                        }
                    }
                    
                    // Save Button
                    Button(action: {
                        if noteText.isEmpty {
                            alertMessage = "Please enter a note"
                            showAlert = true
                        } else {
                            saveNoteApiCall(note: noteText)
                        }
                    }) {
                        Text("Save Note")
                            .fontWeight(.semibold)
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(LinearGradient(colors: [.purple, .pink],
                                                       startPoint: .leading,
                                                       endPoint: .trailing))
                            .foregroundColor(.white)
                            .cornerRadius(12)
                            .shadow(radius: 2)
                    }
                    .padding(.top, 6)
                }
                .padding(.horizontal)
                
                Spacer(minLength: 15)
                
                // Notes List
                if notes.isEmpty {
                    VStack(spacing: 8) {
                        Image(systemName: "square.and.pencil")
                            .resizable()
                            .frame(width: 50, height: 50)
                            .foregroundColor(.purple.opacity(0.6))
                        Text("No notes yet")
                            .font(.headline)
                            .foregroundColor(.purple.opacity(0.8))
                        Text("Start writing your first memory!")
                            .font(.subheadline)
                            .foregroundColor(.gray)
                    }
                    .frame(maxHeight: .infinity, alignment: .center)
                } else {
                    List {
                        ForEach(notes) { note in
                            VStack(alignment: .leading, spacing: 4) {
                                Text(note.note)
                                    .font(.system(size: 18, weight: .medium, design: .serif))
                                    .foregroundColor(.black)
                                if let created = note.created_at {
                                    Text(created)
                                        .font(.caption)
                                        .foregroundColor(.gray)
                                }
                            }
                        }
                        .onDelete(perform: deleteNote) // 👈 Swipe to delete
                    }
                    .listStyle(PlainListStyle())
                }
            }
            .frame(width: geometry.size.width, height: geometry.size.height)
            .background(Color(white: 0.97).ignoresSafeArea())
        }
        .onAppear {
            fetchNotesApiCall()
        }
        .alert("Message", isPresented: $showAlert) {
            Button("OK", role: .cancel) { }
        } message: {
            Text(alertMessage)
        }
    }
    
    // MARK: - API Calls
    
    func saveNoteApiCall(note: String) {
        let params: [String: Any] = [
            "email": Manager.shared.email,
            "note": note
        ]
        
        APIHandler.shared.postAPIValues(
            type: NoteResponseModel.self,
            apiUrl: APIList.add_noteURl,
            method: "POST",
            formData: params
        ) { result in
            DispatchQueue.main.async {
                switch result {
                case .success(_):
                    noteText = ""
                    fetchNotesApiCall()
                case .failure(let err):
                    alertMessage = "Failed to save note: \(err.localizedDescription)"
                    showAlert = true
                }
            }
        }
    }
    
    func fetchNotesApiCall() {
        let urlWithEmail = "\(APIList.get_noteURl)?email=\(Manager.shared.email)"
        
        APIHandler.shared.getAPIValues(
            type: NotesListResponseModel.self,
            apiUrl: urlWithEmail,
            method: "GET"
        ) { result in
            DispatchQueue.main.async {
                switch result {
                case .success(let response):
                    notes = response.data
                case .failure(let err):
                    alertMessage = "Failed to fetch notes: \(err.localizedDescription)"
                    showAlert = true
                }
            }
        }
    }
    
    func deleteNote(at offsets: IndexSet) {
        for index in offsets {
            let note = notes[index]
            if let id = note.id as Int? {
                deleteNoteApiCall(id: id)
            }
        }
        notes.remove(atOffsets: offsets) // Update UI instantly
    }
    
    func deleteNoteApiCall(id: Int) {
        let params: [String: Any] = ["id": id]
        
        APIHandler.shared.postAPIValues(
            type: NoteResponseModel.self,
            apiUrl: APIList.delete_noteURl,
            method: "POST",
            formData: params
        ) { result in
            DispatchQueue.main.async {
                switch result {
                case .success(let response):
                    print("✅ Note deleted:", response.message)
                case .failure(let err):
                    alertMessage = "Failed to delete note: \(err.localizedDescription)"
                    showAlert = true
                }
            }
        }
    }
}

// MARK: - Models
struct NoteResponseModel: Codable {
    let status: Bool
    let message: String
    let data: [NoteItem]?
}

struct NotesListResponseModel: Codable {
    let status: Bool
    let message: String
    let data: [NoteItem]
}

struct NoteItem: Codable, Identifiable {
    let id: Int
    let email: String?
    let note: String
    let created_at: String?
}


// MARK: - Preview
struct PartyNotesView_Previews: PreviewProvider {
    static var previews: some View {
        PartyNotes()
    }
}
