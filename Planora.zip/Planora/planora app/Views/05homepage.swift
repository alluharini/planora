import SwiftUI

struct homepage: View {
    @State var eventlist = [GetEventDatum]()
    @State private var showingLogoutConfirmation = false
    @State private var navigateToWelcome = false
    @State private var username: String = ""
    
    // Error handling
    @State private var showError = false
    @State private var errorMessage = ""
    
    // Track selected tab
    @State private var selectedTab: BarButton = .home
    
    var body: some View {
        NavigationStack {
            GeometryReader { geometry in
                VStack(spacing: 0) {
                    
                    // Top Bar (only for Home)
                    if selectedTab == .home {
                        HStack {
                            Text("Hello, \(username)!!")
                                .font(.system(size: geometry.size.width * 0.08))
                                .foregroundColor(Color.purple.opacity(0.8))
                                .padding(.leading, geometry.size.width * 0.04)
                            
                            Spacer()
                            
                            Menu {
                                Button(role: .destructive) {
                                    showingLogoutConfirmation = true
                                    UserDefaults.standard.set("", forKey: "username")
                                } label: {
                                    Text("Logout")
                                        .foregroundColor(.red)
                                }
                            } label: {
                                Image(systemName: "line.horizontal.3")
                                    .resizable()
                                    .frame(width: geometry.size.width * 0.08,
                                           height: geometry.size.width * 0.06)
                                    .foregroundColor(.black)
                            }
                            .padding(.trailing, geometry.size.width * 0.04)
                        }
                        .padding(.top, geometry.size.height * 0.02)
                        .padding(.bottom, geometry.size.height * 0.01)
                    }
                    
                    // Content area
                    Group {
                        switch selectedTab {
                        case .home:
                            homeContent(geometry: geometry)
                        case .createEvent:
                            CreateEventPage(selectedTab: $selectedTab) // Pass binding
                        case .more:
                            MorePageView()
                        case .settings:
                            SettingsView()
                        }
                    }
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                    
                    // Bottom Bar only on main tabs
                    if [.home, .createEvent, .more, .settings].contains(selectedTab) {
                        bottomBar()
                    }
                }
                .navigationDestination(isPresented: $navigateToWelcome) {
                    welcomepage()
                }
                .onAppear {
                    if selectedTab == .home {
                        getEvent()
                        if let savedUsername = UserDefaults.standard.string(forKey: "username") {
                            username = savedUsername
                        }
                    }
                }
                .onChange(of: selectedTab) { oldValue, newValue in
                    if newValue == .home {
                        getEvent()
                    }
                }


                .alert("Logout?", isPresented: $showingLogoutConfirmation) {
                    Button("Cancel", role: .cancel) {}
                    Button("Logout", role: .destructive) {
                        navigateToWelcome = true
                    }
                }
            }
        }
        .navigationBarHidden(true)
    }
    
    // MARK: - Home Content
    @ViewBuilder
    func homeContent(geometry: GeometryProxy) -> some View {
        if showError {
            VStack(spacing: 16) {
                Image(systemName: "wifi.exclamationmark")
                    .resizable()
                    .scaledToFit()
                    .frame(width: geometry.size.width * 0.2)
                    .foregroundColor(.red)
                
                Text("Oops! Something went wrong.")
                    .font(.title3)
                    .foregroundColor(.red)
                
                Text(errorMessage)
                    .font(.body)
                    .foregroundColor(.gray)
                    .multilineTextAlignment(.center)
                    .padding(.horizontal)
                
                Button(action: {
                    showError = false
                    errorMessage = ""
                    getEvent()
                }) {
                    Text("Retry")
                        .fontWeight(.semibold)
                        .padding()
                        .frame(maxWidth: .infinity)
                        .background(Color.purple.opacity(0.8))
                        .foregroundColor(.white)
                        .cornerRadius(12)
                        .padding(.horizontal, geometry.size.width * 0.1)
                }
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
        } else if eventlist.isEmpty {
            VStack(spacing: 16) {
                Image(systemName: "calendar.badge.exclamationmark")
                    .resizable()
                    .scaledToFit()
                    .frame(width: geometry.size.width * 0.25)
                    .foregroundColor(.purple.opacity(0.6))
                
                Text("No events yet.")
                    .font(.title2)
                    .foregroundColor(.purple)
                
                Text("Tap ‘Create’ to add one!")
                    .font(.body)
                    .foregroundColor(.gray)
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
        } else {
            ScrollViewReader { proxy in
                List {
                    ForEach(eventlist) { event in
                        VStack(spacing: 0) {
                            EventCardView(event: event)
                                .padding(.vertical, 8)
                        }
                        .listRowInsets(EdgeInsets())
                        .listRowBackground(Color.gray.opacity(0.05))
                        .id(event.id) // For scrolling
                    }
                    .onDelete(perform: deleteItems)
                }
                .listStyle(PlainListStyle())
                .scrollContentBackground(.hidden)
                .background(
                    LinearGradient(
                        gradient: Gradient(colors: [
                            Color(red: 0.98, green: 0.98, blue: 1.0),
                            Color(red: 0.95, green: 0.95, blue: 0.98)
                        ]),
                        startPoint: .top,
                        endPoint: .bottom
                    )
                )
                .onChange(of: eventlist.count) { oldCount, newCount in
                    if let firstID = eventlist.first?.id {
                        withAnimation {
                            proxy.scrollTo(firstID, anchor: .top)
                        }
                    }
                }

            }
        }
    }
    
    // MARK: - Bottom Bar
    @ViewBuilder
    func bottomBar() -> some View {
        GeometryReader { geometry in
            HStack(spacing: 0) {
                ForEach(BarButton.allCases, id: \.self) { type in
                    Button {
                        selectedTab = type
                        if type == .home {
                            getEvent()
                            if let savedUsername = UserDefaults.standard.string(forKey: "username") {
                                username = savedUsername
                            }
                        }
                    } label: {
                        VStack(spacing: 2) {
                            Image(systemName: type.iconName)
                                .font(.system(size: 24, weight: selectedTab == type ? .bold : .regular))
                                .foregroundColor(selectedTab == type ? .purple : .black)
                            Text(type.title)
                                .font(.system(size: 12))
                                .fontWeight(selectedTab == type ? .bold : .regular)
                                .foregroundColor(selectedTab == type ? .purple : .black)
                        }
                        .frame(maxWidth: .infinity)
                    }
                    if type != .more {
                        Spacer(minLength: 0)
                    }
                }
            }
            .padding(.vertical, 8)
            .padding(.horizontal, 16)
            .background(
                Color(red: 0.7, green: 0.6, blue: 0.95)
                    .cornerRadius(16)
                    .shadow(radius: 5)
                    .edgesIgnoringSafeArea(.bottom)
            )
            .padding(.bottom, geometry.safeAreaInsets.bottom + 8)
        }
        .frame(height: 45)
    }
    
    // MARK: - Fetch Events
    func getEvent() {
        let email = Manager.shared.email
        let url = APIList.geteventUrl + "?email=\(email)"
        
        APIHandler.shared.getAPIValues(type: GetEvent.self, apiUrl: url, method: "POST") { result in
            DispatchQueue.main.async {
                switch result {
                case .success(let response):
                    eventlist = response.data
                    showError = false
                    errorMessage = ""
                case .failure(let err):
                    showError = true
                    errorMessage = err.localizedDescription.isEmpty ? "Failed to load events." : err.localizedDescription
                }
            }
        }
    }
    
    // MARK: - Delete Event
    func deleteEventFromServer(eventID: String, completion: @escaping (Bool) -> Void) {
        guard let url = URL(string: "http://14.139.187.229:8081/planora/delete_event.php") else {
            completion(false)
            return
        }
        
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        
        let boundary = UUID().uuidString
        request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")
        
        var body = Data()
        body.append("--\(boundary)\r\n".data(using: .utf8)!)
        body.append("Content-Disposition: form-data; name=\"eventId\"\r\n\r\n".data(using: .utf8)!)
        body.append("\(eventID)\r\n".data(using: .utf8)!)
        body.append("--\(boundary)--\r\n".data(using: .utf8)!)
        
        request.httpBody = body
        
        URLSession.shared.dataTask(with: request) { data, _, error in
            if error != nil {
                completion(false)
                return
            }
            completion(true)
        }.resume()
    }
    
    func deleteItems(at offsets: IndexSet) {
        for index in offsets {
            let event = eventlist[index]
            deleteEventFromServer(eventID: String(event.id)) { success in
                if success {
                    DispatchQueue.main.async {
                        eventlist.remove(atOffsets: offsets)
                    }
                }
            }
        }
    }
}

// MARK: - Event Card


struct EventCardView: View {
    let event: GetEventDatum
    
    var body: some View {
        NavigationLink(
            destination: PreferenceView()
                .navigationBarBackButtonHidden(false)
                .navigationBarTitleDisplayMode(.inline)
                .toolbarBackground(.visible, for: .navigationBar)
                .toolbarBackground(.ultraThinMaterial, for: .navigationBar)
                .toolbarColorScheme(.light, for: .navigationBar)
                .toolbar {
                    ToolbarItem(placement: .navigationBarLeading) {
//                        Button(action: {}) {
//                            Image(systemName: "chevron.left")
//                                .foregroundColor(.black)
//                        }
                    }
                }
        ) {
            HStack {
                VStack(alignment: .leading, spacing: 6) {
                    Text(event.eventName)
                        .font(.headline)
                        .foregroundColor(.black)
                    
                    Text(event.eventDate)
                        .font(.subheadline)
                        .foregroundColor(.gray)
                }
                Spacer()
                Image(systemName: "chevron.right")
                    .foregroundColor(.black)
            }
            .padding()
            .frame(maxWidth: .infinity)
            .background(
                LinearGradient(
                    gradient: Gradient(colors: [Color.pink.opacity(0.3), Color.purple.opacity(0.5)]),
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                )
            )
            .cornerRadius(16)
            .shadow(color: Color.black.opacity(0.1), radius: 4, x: 0, y: 2)
            .padding(.horizontal)
        }
    }
}

// MARK: - Bottom Bar Enum
enum BarButton: CaseIterable {
    case createEvent, home, more, settings
    
    var iconName: String {
        switch self {
        case .createEvent: return "pencil"
        case .home: return "house"
        case .more: return "message"
        case .settings: return "gearshape"
        }
    }
    
    var title: String {
        switch self {
        case .createEvent: return "Create"
        case .home: return "Home"
        case .more: return "More"
        case .settings: return "Settings"
        }
    }
}

// MARK: - Preview
struct homepage_Previews: PreviewProvider {
    static var previews: some View {
        homepage()
    }
}

