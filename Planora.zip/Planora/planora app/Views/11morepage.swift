import SwiftUI

struct MorePageView: View {
    let purpleColor = Color.purple.opacity(0.8)
    
    @State private var selectedItem: ContentItem? = nil
    @State private var isActive: Bool = false
    
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 9) {
                    // Header
                    HStack {
                        Text("More Page")
                            .font(.largeTitle.bold())
                            .foregroundColor(Color.purple.opacity(0.8))
                        Spacer()
                    }
                    .padding([.top, .horizontal])
                    .padding(.top,-20)
                    
                    // Content Tiles
                    ForEach(contentData) { item in
                        Button {
                            selectedItem = item
                            // Smooth fade animation instead of slide
                            withAnimation(.easeInOut(duration: 0.35)) {
                                isActive = true
                            }
                        } label: {
                            VStack(spacing: 18) {
                                Image(item.imageName)
                                    .resizable()
                                    .scaledToFill()
                                    .frame(height: 150)
                                    .clipped()
                                    .cornerRadius(16)
                                
                                Text(item.title)
                                    .font(.headline)
                                    .foregroundColor(purpleColor)
                                    .frame(maxWidth: .infinity)
                                    .multilineTextAlignment(.center)
                            }
                            .padding()
                            .background(Color(.systemBackground))
                            .cornerRadius(20)
                            .shadow(color: Color.black.opacity(0.05), radius: 8, x: 0, y: 4)
                        }
                        .padding(.horizontal)
                    }
                    .padding(.bottom, 20)
                    
                    if let item = selectedItem {
                        Color.clear
                            .frame(width: 0, height: 0)
                            .navigationDestination(isPresented: $isActive) {
                                item.destination
                                    .navigationBarBackButtonHidden(false)
                                    .navigationBarTitleDisplayMode(.inline)
                                    .transition(.opacity.combined(with: .scale))
                            }
                    }

                    
                }
            }
            .navigationBarHidden(true)
            .background(Color(.systemGroupedBackground).ignoresSafeArea())
        }
        .navigationViewStyle(.stack)
    }
}

// MARK: - Model and Data
struct ContentItem: Identifiable {
    let id = UUID()
    let title: String
    let imageName: String
    let destination: AnyView
}

let contentData: [ContentItem] = [
    .init(title: "Leftover Ideas", imageName: "leftover", destination: AnyView(LeftoverIdeas())),
    .init(title: "Party Notes", imageName: "notes", destination: AnyView(PartyNotesView())),
    .init(title: "Shopping List", imageName: "shopping", destination: AnyView(ShoppingListView()))
]

// MARK: - Preview
struct MorePageView_Previews: PreviewProvider {
    static var previews: some View {
        MorePageView()
    }
}
