import SwiftUI

struct ShoppingListView: View {
    let purpleColor = Color.purple.opacity(0.8)
    
    @State private var selectedItem: ShoppingItem? = nil
    @State private var isActive: Bool = false
    
    var body: some View {
        NavigationStack {
            ZStack {
                // Gradient background
                LinearGradient(
                    gradient: Gradient(colors: [Color.purple.opacity(0.2), Color.white]),
                    startPoint: .top,
                    endPoint: .bottom
                )
                .edgesIgnoringSafeArea(.all)
                
                ScrollView {
                    VStack(spacing: 20) {
                        // Centered Header
                        Text("Shopping List")
                            .font(.largeTitle.bold())
                            .foregroundColor(purpleColor)
                            .frame(maxWidth: .infinity)
                            .multilineTextAlignment(.center)
                            .padding(.top, 10)
                        
                        // Cards
                        ForEach(shoppingItems) { item in
                            Button {
                                selectedItem = item
                                withAnimation(.easeInOut(duration: 0.35)) {
                                    isActive = true
                                }
                            } label: {
                                VStack(spacing: 12) {
                                    Image(item.imageName)
                                        .resizable()
                                        .scaledToFill()
                                        .frame(height: 230) // ✅ Reduced height
                                        .clipped()
                                        .cornerRadius(16)
                                    
                                    Text(item.title)
                                        .font(.headline)
                                        .foregroundColor(purpleColor)
                                        .frame(maxWidth: .infinity)
                                        .multilineTextAlignment(.center)
                                }
                                .padding()
                                .background(Color(.systemBackground))
                                .cornerRadius(20)
                                .shadow(color: Color.black.opacity(0.05), radius: 8, x: 0, y: 4)
                            }
                            .padding(.horizontal)
                        }
                        .padding(.bottom, 30)
                        
                        // Navigation logic
                        if let item = selectedItem {
                            Color.clear
                                .frame(width: 0, height: 0)
                                .navigationDestination(isPresented: $isActive) {
                                    item.destination
                                        .navigationBarBackButtonHidden(false)
                                        .navigationBarTitleDisplayMode(.inline)
                                        .transition(.opacity.combined(with: .scale))
                                }
                        }
                    }
                    .padding(.top, 10)
                }
            }
            .navigationBarHidden(true)
        }
        .navigationViewStyle(.stack)
    }
}

// MARK: - Model & Data
struct ShoppingItem: Identifiable {
    let id = UUID()
    let title: String
    let imageName: String
    let destination: AnyView
}

let shoppingItems: [ShoppingItem] = [
    .init(title: "Manual Entry", imageName: "manual", destination: AnyView(GroceryListView())),
    .init(title: "Ai Generated", imageName: "ai", destination: AnyView(AIGroceryListView()))
]

// MARK: - Preview
struct ShoppingListView_Previews: PreviewProvider {
    static var previews: some View {
        ShoppingListView()
    }
}

