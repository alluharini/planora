import SwiftUI

struct ViewOffsetKey: PreferenceKey {
    static var defaultValue: CGFloat = 0
    static func reduce(value: inout CGFloat, nextValue: () -> CGFloat) {
        value = nextValue()
    }
}

extension AIfooddRecommended {
    var adjustedPrice: Int {
        let multiplier: Double
        switch Manager.shared.selectedPriceLevel {
        case "medium": multiplier = 2.0
        case "premium": multiplier = 3.0
        default: multiplier = 1.0
        }
        return Int(Double(price) * multiplier)
    }
}

struct DishSelectionView: View {
    @State private var mandatoryItems: [String] = [
        "Plain Rice", "Chapati", "Salad", "Papad", "Curd", "Pickle", "ice cream", "sweet", "gulab jamun", "samosa", "cold drink", "juice", "chips", "pani puri"
    ]

    @State private var selectedItems: [AIfooddRecommended] = []
    @State private var guestAllocations: [AIfooddRecommended: Int] = [:]
    @State private var addMandatoryItems = false
    @State private var selectedMandatory: Set<String> = []
    @State private var showScrollHint = true

    let mandatoryPricesByLevel: [String: [String: Int]] = [
        "basic": [
            "Plain Rice": 18, "Chapati": 10, "Salad": 9, "Papad": 5, "Curd": 10,
            "Pickle": 5, "Ice Cream": 20, "Sweet": 10, "Gulab Jamun": 10,
            "Samosa": 10, "Cold Drink": 15, "Juice": 20, "Chips": 5, "Pani Puri": 10
        ],
        "medium": [
            "Plain Rice": 25, "Chapati": 20, "Salad": 15, "Papad": 10, "Curd": 15,
            "Pickle": 13, "Ice Cream": 30, "Sweet": 20, "Gulab Jamun": 15,
            "Samosa": 20, "Cold Drink": 25, "Juice": 30, "Chips": 10, "Pani Puri": 20
        ],
        "premium": [
            "Plain Rice": 50, "Chapati": 40, "Salad": 35, "Papad": 20, "Curd": 25,
            "Pickle": 20, "Ice Cream": 50, "Sweet": 40, "Gulab Jamun": 35,
            "Samosa": 40, "Cold Drink": 50, "Juice": 48, "Chips": 30, "Pani Puri": 40
        ]
    ]

    let dishCategoryMapping: [String: String] = [
        // Appetizers
        "Sweet Momos": "Appetizers",
        "Spicy Rolls": "Appetizers",
        "Tasty Rolls": "Appetizers",
        "Fried Momos": "Appetizers",
        "Delicious Momos": "Appetizers",
        "Grilled Momos": "Appetizers",
        "Tasty Momos": "Appetizers",
        "Spicy Momos": "Appetizers",
        

        // Soup (including Stew)
        "Delicious Soup": "Soup",
        "Tasty Soup": "Soup",
        "Grilled Soup": "Soup",
        "Sweet Soup": "Soup",
        "Fried Soup": "Soup",
        "Spicy Soup": "Soup",
        "Delicious Stew": "Soup",
        "Tasty Stew": "Soup",
        "Grilled Stew": "Soup",
        "Sweet Stew": "Soup",
        "Fried Stew": "Soup",
        "Spicy Stew": "Soup",

        // Starters / Salads
        "Delicious Salad": "Appetizers",
        "Tasty Salad": "Appetizers",
        "Grilled Salad": "Appetizers",
        "Fried Salad": "Appetizers",
        "Sweet Salad": "Appetizers",
        "Spicy Salad": "Appetizers",

        // Main Course
        "Delicious Pizza": "Main Course",
        "Tasty Pizza": "Main Course",
        "Sweet Pizza": "Main Course",
        "Grilled Pizza": "Main Course",
        "Fried Pizza": "Main Course",
        "Delicious Pasta": "Main Course",
        "Tasty Pasta": "Main Course",
        "Sweet Pasta": "Main Course",
        "Grilled Pasta": "Main Course",
        "Fried Pasta": "Main Course",
        "Delicious Biryani": "Main Course",
        "Tasty Biryani": "Main Course",
        "Sweet Biryani": "Main Course",
        "Grilled Biryani": "Main Course",
        "Fried Biryani": "Main Course",
        "Spicy Biryani": "Main Course",
        "Tasty Tacos": "Main Course",
        "Sweet Tacos": "Main Course",
        "Fried Tacos": "Main Course",
        "Delicious Tacos": "Main Course",
        "Grilled Tacos": "Main Course",
        "Spicy Tacos": "Main Course",
        "Grilled Sushi": "Main Course",
        "Delicious Sushi": "Main Course",
        "Tasty Sushi": "Main Course",
        "Sweet Sushi": "Main Course",
        "Fried Sushi": "Main Course",
        "Spicy Sushi": "Main Course",

        // Dessert
        "Sweet Rolls": "Dessert",
        "Delicious Rolls": "Dessert",
        "Fried Rolls": "Dessert",
        "Ice Cream": "Dessert",
        "Mango Kulfi": "Dessert",
        "Gulab Jamun": "Dessert",
        "Rasgulla": "Dessert",
        "Kesar Pista Ice Cream": "Dessert",
        "Rabri": "Dessert",
        "Coconut Ladoo": "Dessert",
        "Malai Sandwich Ice Cream": "Dessert",

    ]

    var uniqueRecommendedDishes: [AIfooddRecommended] {
        var seenNames = Set<String>()
        return Manager.shared.recommendedDish.filter { dish in
            if seenNames.contains(dish.name) {
                return false
            } else {
                seenNames.insert(dish.name)
                return true
            }
        }
    }

    var categorizedDishes: [String: [AIfooddRecommended]] {
        var dict: [String: [AIfooddRecommended]] = [:]
        for dish in uniqueRecommendedDishes {
            let category = dishCategoryMapping[dish.name] ?? "Others"
            if dict[category] != nil {
                dict[category]!.append(dish)
            } else {
                dict[category] = [dish]
            }
        }
        return dict
    }

    var totalPriceValue: Int {
        guestAllocations.reduce(0) { result, entry in
            let (dish, guestCount) = entry
            return result + (dish.adjustedPrice * guestCount)
        }
    }

    var body: some View {
        GeometryReader { geo in
            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    if showScrollHint {
                        HStack {
                            Spacer()
                            VStack(spacing: 4) {
                                Text("Scroll down for more")
                                    .font(.footnote)
                                    .foregroundColor(.gray)
                                Image(systemName: "arrow.down")
                                    .foregroundColor(.gray)
                            }
                            Spacer()
                        }
                        .padding(.top, 10)
                    }

                    // Loop through categories in a fixed order
                    ForEach(["Appetizers", "Soup", "Main Course", "Dessert", "Others"], id: \.self) { section in
                        if let dishes = categorizedDishes[section], !dishes.isEmpty {
                            VStack(alignment: .leading, spacing: 10) {
                                Text(section)
                                    .font(.title2)
                                    .bold()
                                    .foregroundColor(.purple)
                                    .padding(.horizontal)
                                
                                ForEach(dishes, id: \.name) { item in
                                    VStack(alignment: .leading) {
                                        HStack {
                                            Text(item.name).italic()
                                            Spacer()
                                            Button(action: {
                                                if selectedItems.contains(item) {
                                                    selectedItems.removeAll { $0 == item }
                                                    guestAllocations[item] = nil
                                                } else {
                                                    selectedItems.append(item)
                                                    guestAllocations[item] = 0
                                                }
                                            }) {
                                                ZStack {
                                                    RoundedRectangle(cornerRadius: 4)
                                                        .stroke(Color.black, lineWidth: 2)
                                                        .frame(width: 24, height: 24)
                                                    if selectedItems.contains(item) {
                                                        Image(systemName: "checkmark")
                                                            .font(.system(size: 18, weight: .bold))
                                                            .foregroundColor(Color.purple)
                                                    }
                                                }
                                            }
                                        }
                                        Text("Cuisine: \(item.cuisine)").font(.subheadline).foregroundColor(.gray)
                                        Text("Dietary: \(item.diet)").font(.subheadline).foregroundColor(.gray)
                                        Text("Price: ₹\(item.adjustedPrice)").font(.subheadline).foregroundColor(.gray)
                                    }
                                    .padding(.horizontal)
                                }
                            }
                        }
                    }

                    if !selectedItems.isEmpty {
                        Text("Guest Allocation")
                            .font(.title2).bold()
                            .foregroundColor(.purple)
                            .padding(.horizontal)

                        ForEach(selectedItems, id: \.name) { item in
                            HStack {
                                Text(item.name).italic()
                                Spacer()
                                TextField(
                                    "Enter guest count",
                                    text: Binding(
                                        get: {
                                            if let value = guestAllocations[item], value != 0 {
                                                return String(value)
                                            } else {
                                                return ""
                                            }
                                        },
                                        set: { newValue in
                                            if let intValue = Int(newValue) {
                                                guestAllocations[item] = intValue
                                            } else if newValue.isEmpty {
                                                guestAllocations[item] = 0
                                            }
                                        }
                                    )
                                )
                                .keyboardType(.numberPad)
                                .padding(8)
                                .frame(width: 200)
                                .background(
                                    LinearGradient(
                                        gradient: Gradient(colors: [.purple.opacity(0.2), .blue.opacity(0.2)]),
                                        startPoint: .leading,
                                        endPoint: .trailing
                                    )
                                )
                                .cornerRadius(8)
                                .overlay(
                                    RoundedRectangle(cornerRadius: 8)
                                        .stroke(Color.purple.opacity(0.6), lineWidth: 1)
                                )
                            }
                            .padding(.horizontal)
                        }
                    }

                    HStack {
                        Toggle(isOn: $addMandatoryItems) {
                            Text("Add Mandatory Menu Items for All Guests?")
                                .italic()
                                .foregroundColor(.purple)
                        }
                        .tint(.purple)
                    }
                    .padding()
                    .background(RoundedRectangle(cornerRadius: 10).fill(Color.purple.opacity(0.3)))
                    .padding(.horizontal)

                    if addMandatoryItems {
                        ForEach(mandatoryItems, id: \.self) { item in
                            HStack {
                                Text("\(item.capitalized) - ₹\(mandatoryPricesByLevel[Manager.shared.selectedPriceLevel]?[item.capitalized] ?? 0)")
                                    .italic()
                                Spacer()
                                Button(action: {
                                    if selectedMandatory.contains(item) {
                                        selectedMandatory.remove(item)
                                    } else {
                                        selectedMandatory.insert(item)
                                    }
                                }) {
                                    ZStack {
                                        RoundedRectangle(cornerRadius: 4)
                                            .stroke(Color.black, lineWidth: 2)
                                            .frame(width: 24, height: 24)
                                        if selectedMandatory.contains(item) {
                                            Image(systemName: "checkmark").foregroundColor(.purple)
                                        }
                                    }
                                }
                            }
                            .padding(.horizontal)
                        }
                    }

                    NavigationLink(destination: BudgetView(
                        selectedDishes: selectedItems,
                        selectedMandatory: selectedMandatory,
                        guestAllocations: guestAllocations,
                        totalGuests: Manager.shared.totalGuest,
                        priceLevel: Manager.shared.selectedPriceLevel
                    )) {
                        Text("View Budget →")
                            .font(.headline)
                            .italic()
                            .foregroundColor(.white)
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Color.purple)
                            .cornerRadius(25)
                            .padding(.horizontal)
                    }

                }
                .background(
                    GeometryReader { innerGeo in
                        Color.clear
                            .preference(key: ViewOffsetKey.self, value: innerGeo.frame(in: .named("scroll")).minY)
                    }
                )
            }
            .coordinateSpace(name: "scroll")
            .onPreferenceChange(ViewOffsetKey.self) { offset in
                if offset < -50 {
                    withAnimation {
                        showScrollHint = false
                    }
                }
            }
        }
    }
}

struct DishSelectionView_Previews: PreviewProvider {
    static var previews: some View {
        DishSelectionView()
    }
}

