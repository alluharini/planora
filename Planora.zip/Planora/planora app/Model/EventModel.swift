import Foundation

struct EventModel: Identifiable, Codable {
    var id: UUID = UUID()
    let name: String
    let date: String
}
