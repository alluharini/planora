import Foundation

struct LeftoverfoodResponseModel: Codable {
    let status: Bool
    let message: String
    let data: [LeftoverfoodResponsesData]
    
    
    struct LeftoverfoodResponsesData: Codable {
        let id: Int
        let foodName: String
        
        enum CodingKeys: String, CodingKey {
            case id 
            case foodName = "food_name"
        }
    }
}


