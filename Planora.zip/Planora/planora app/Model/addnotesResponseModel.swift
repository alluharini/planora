import Foundation

struct AddnotesResponseModel: Codable {
    let status: Bool
    let message: String
    let data: [AddnotesResponsesData]
    
    
    struct AddnotesResponsesData: Codable {
        let id: Int
        let name: String
        let isChecked:Int
        
        enum CodingKeys: String, CodingKey {
            case id, name
            case isChecked = "is_checked"
        }
    }
}


