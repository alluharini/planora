import Foundation

struct AIfood: Codable {
    let status: Bool
    let message: String
    let data: AIfooddata
}

struct AIfooddata: Codable {
    let totalGuests: Int
    let mandatoryDishes: [String]
    let recommendedDishes: [AIfooddRecommended]

    enum CodingKeys: String, CodingKey {
        case totalGuests = "total_guests"
        case mandatoryDishes = "mandatory_dishes"
        case recommendedDishes = "recommended_dishes"
    }
}

struct AIfooddRecommended: Codable, Hashable, Equatable  {
    let name: String
    let cuisine: String
    let diet: String
    let price: Int
}

struct GetBudegt: Codable {
    let success: Bool
    let message: String
    let data: GetBudegtData
}

// MARK: - DataClass
struct GetBudegtData: Codable {
    let id: Int
    let eventID, totalCost: String
    let totalGuests: Int
    let priceLevel, selectedDishes, mandatoryItems, createdAt: String
    let updatedAt: String

    enum CodingKeys: String, CodingKey {
        case id
        case eventID = "event_id"
        case totalCost = "total_cost"
        case totalGuests = "total_guests"
        case priceLevel = "price_level"
        case selectedDishes = "selected_dishes"
        case mandatoryItems = "mandatory_items"
        case createdAt = "created_at"
        case updatedAt = "updated_at"
    }
}
