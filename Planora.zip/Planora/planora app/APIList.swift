import Foundation
struct APIList {
    static let baseUrl = "http://14.139.187.229:8081/planora/"
    
    
//    //server integration
//    static let baseUrl1Ai = "http://180.235.121.245:4032/recommendations"
//    //leftover
//    static let baseUrlAi = "http://180.235.121.245:4333/recommend_food"
    
    
    //no server just in mac machine
    static let baseUrl1Ai = "http://127.0.0.1:8000/recommendations"
    static let baseUrlAi = "http://127.0.0.1:5000/recommend_food"
    static let aigrocery = "http://127.0.0.1:5000/dish_ingredients"
    
    // AI
    static let foofLeftOver = baseUrlAi
    static let foodai = baseUrl1Ai
    static let budgetai = baseUrlAi
 
    
    
    static let loginUrl = "\(baseUrl)/login.php"
    static let registerUrl = "\(baseUrl)/register.php"
    
    static let eventUrl = "\(baseUrl)/create_event.php"
    static let geteventUrl = "\(baseUrl)/getevents.php"
    static let updateeventUrl = "\(baseUrl)/save_budget.php"
    static let preferenceUrl = "\(baseUrl)/event_request.php"
    
    static let add_noteURl = "\(baseUrl)/add_notes.php"
    static let get_noteURl = "\(baseUrl)/get_notes.php"
    static let delete_noteURl = "\(baseUrl)/delete_notes.php"
    
    static let add_groceryURl = "\(baseUrl)/add_grocery.php"
    static let get_groceryURl = "\(baseUrl)/get_grocery.php"
    static let update_groceryURl = "\(baseUrl)/update_grocery.php"
    static let delete_groceryURl = "\(baseUrl)/delete_grocery.php"
    
    static let leftoverfoodideaURL = "\(baseUrl)/add_leftover_idea.php"
    
    // Budget Endpoints
    static let saveBudgetUrl = "\(baseUrl)/save_budget.php"
    static let get_budgets = baseUrl + "/get_budgets.php"

//    // AI
//    static let foofLeftOver = baseUrlAi
//    static let foodai = baseUrl1Ai
//    static let budgetai = baseUrlAi
    
    
    
    
    
    
    
    
    //    // For iPhone (device testing)
    //    static let baseUrl = "http://172.20.10.4/planora"
    //    static let baseUrl1Ai = "http://172.20.10.4:8000/"
    //    static let baseUrlAi  = "http://172.20.10.4:5000/"
}
