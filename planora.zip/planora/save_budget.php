<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');


$host = "localhost";
$user = "root";
$password = "";
$dbname = "planora";

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $user, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    echo json_encode([
        'success' => false,
        'message' => 'Database connection failed: ' . $e->getMessage()
    ]);
    exit;
}



// Check if it's a POST request
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode([
        'success' => false,
        'message' => 'Only POST method is allowed'
    ]);
    exit;
}

// Get POST data
$data = json_decode(file_get_contents('php://input'), true);

// If JSON decode failed, try getting form data
if ($data === null) {
    $data = $_POST;
}

// Validate required fields
$required_fields = ['event_id', 'total_cost', 'total_guests', 'price_level', 'selected_dishes', 'mandatory_items'];
foreach ($required_fields as $field) {
    if (!isset($data[$field])) {
        echo json_encode([
            'success' => false,
            'message' => "Missing required field: $field"
        ]);
        exit;
    }
}

try {
    // Prepare the SQL statement
    $sql = "INSERT INTO budgets (event_id, total_cost, total_guests, price_level, selected_dishes, mandatory_items) 
            VALUES (:event_id, :total_cost, :total_guests, :price_level, :selected_dishes, :mandatory_items)";
    
    $stmt = $pdo->prepare($sql);
    
    // Execute with parameters
    $stmt->execute([
        ':event_id' => $data['event_id'],
        ':total_cost' => $data['total_cost'],
        ':total_guests' => $data['total_guests'],
        ':price_level' => $data['price_level'],
        ':selected_dishes' => json_encode($data['selected_dishes']),
        ':mandatory_items' => json_encode($data['mandatory_items'])
    ]);
    
    echo json_encode([
        'success' => true,
        'message' => 'Budget saved successfully',
        'budget_id' => $pdo->lastInsertId()
    ]);
    
} catch(PDOException $e) {
    echo json_encode([
        'success' => false,
        'message' => 'Error saving budget: ' . $e->getMessage()
    ]);
}
?>