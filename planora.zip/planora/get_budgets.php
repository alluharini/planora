<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET');
header('Access-Control-Allow-Headers: Content-Type');

// DB connection
$host = "localhost";
$user = "root";
$password = "";
$dbname = "planora";

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $user, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    echo json_encode([
        'success' => false,
        'message' => 'Database connection failed: ' . $e->getMessage(),
        'data' => []
    ]);
    exit;
}

// Fetch the most recently added budget row
try {
    $stmt = $pdo->prepare("SELECT * FROM budgets ORDER BY id DESC LIMIT 1");
    $stmt->execute();
    $budget = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($budget) {
        $budget['selected_dishes'] = json_decode($budget['selected_dishes'], true);
        $budget['mandatory_items'] = json_decode($budget['mandatory_items'], true);

        echo json_encode([
            'success' => true,
            'message' => 'Latest budget fetched successfully',
            'data' => $budget
        ]);
    } else {
        echo json_encode([
            'success' => false,
            'message' => 'No budget entries found',
            'data' => []
        ]);
    }
} catch(PDOException $e) {
    echo json_encode([
        'success' => false,
        'message' => 'Error fetching latest budget: ' . $e->getMessage(),
        'data' => []
    ]);
}
?>
