from fastapi import FastAPI, HTTPException, Form, Request
import csv

app = FastAPI()

# Load dishes from CSV file
def load_dishes_from_csv(filename="large_dishes_dataset.csv"):
    dishes = []
    with open(filename, mode='r', newline='') as file:
        reader = csv.DictReader(file)
        for row in reader:
            row['price'] = int(row['price'])  # Convert price to int
            dishes.append(row)
    return dishes

# Calculate cost given guest assignments
def calculate_cost(assigned_guests: dict, dishes):
    total_cost = 0
    breakdown = []
    for dish_name, guest_count in assigned_guests.items():
        for dish in dishes:
            if dish['name'].lower() == dish_name.lower():
                cost = guest_count * dish['price']
                total_cost += cost
                breakdown.append({
                    "dish": dish['name'],
                    "guests": guest_count,
                    "price_per_guest": dish['price'],
                    "total": cost
                })
                break
    return total_cost, breakdown

# --- API Endpoints ---

@app.post("/recommendations")
def get_recommendations(
    total_guests: int = Form(...),
    cuisines: str = Form(...),  # comma-separated, e.g. "indian, chinese"
    diets: str = Form(...),     # comma-separated, e.g. "vegetarian, vegan"
    price_level: str = Form(...)
):
    dishes = load_dishes_from_csv()

    # Parse cuisines and diets, empty means no filtering (match all)
    cuisine_list = [c.strip().lower() for c in cuisines.split(",") if c.strip()] if cuisines else []
    diet_list = [d.strip().lower() for d in diets.split(",") if d.strip()] if diets else []

    price_range = {
    'basic': (0, 30),       # 0 instead of 10
    'medium': (31, 50),
    'premium': (51, 200)    # Extend upper limit
}


    filtered = []
    for dish in dishes:
        dish_cuisine = dish['cuisine'].lower()
        dish_diet = dish['diet'].lower()

        # Match if dish matches ANY cuisine in cuisine_list or if no cuisine filter
        cuisine_match = True if not cuisine_list else any(c in dish_cuisine for c in cuisine_list)
        # Match if dish matches ANY diet in diet_list or if no diet filter
        diet_match = True if not diet_list else any(d in dish_diet for d in diet_list)
        # Check price range
        price_match = price_range[price_level][0] <= dish['price'] <= price_range[price_level][1]

        if cuisine_match and diet_match and price_match:
            filtered.append(dish)

    if not filtered:
        raise HTTPException(status_code=404, detail="No dishes found matching preferences")

    # Always include ice cream dishes if present
    mandatory_dishes = [d for d in filtered if 'ice cream' in d['name'].lower()]

    return {
        "status": True,
        "message": "Filtered dishes based on preferences",
        "data": {
            "total_guests": total_guests,
            "mandatory_dishes": mandatory_dishes,
            "recommended_dishes": filtered
        }
    }

@app.post("/calculate")
async def calculate_total(request: Request):
    form_data = await request.form()
    assigned_guests = {}

    for dish_name, value in form_data.items():
        try:
            quantity = int(value)
            if quantity > 0:
                # Replace underscores with spaces and capitalize words to match CSV naming
                formatted_name = dish_name.replace("_", " ").title()
                assigned_guests[formatted_name] = quantity
        except ValueError:
            continue  # Skip invalid integers

    if not assigned_guests:
        return {
            "status": False,
            "message": "No valid dish data provided",
            "data": []
        }

    dishes = load_dishes_from_csv()
    total_cost, breakdown = calculate_cost(assigned_guests, dishes)

    return {
        "status": True,
        "message": "Cost calculated successfully",
        "data": {
            "total_cost": total_cost,
            "breakdown": breakdown
        }
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("code_ai:app", host="127.0.0.1", port=8000, reload=True)
